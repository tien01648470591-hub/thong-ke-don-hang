package vn.thongkedonhang.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.collectLatest
import vn.thongkedonhang.app.ui.MainViewModel
import vn.thongkedonhang.app.ui.SearchScopeMode
import vn.thongkedonhang.app.ui.screens.AddOrderScreen
import vn.thongkedonhang.app.ui.screens.BackupRestoreScreen
import vn.thongkedonhang.app.ui.screens.CalendarStatsScreen
import vn.thongkedonhang.app.ui.screens.OrderDetailScreen
import vn.thongkedonhang.app.ui.screens.OrderGroupScreen
import vn.thongkedonhang.app.ui.screens.OrderListScreen
import vn.thongkedonhang.app.ui.screens.OverviewScreen
import vn.thongkedonhang.app.ui.screens.TotalReportScreen
import vn.thongkedonhang.app.ui.theme.PrimaryYellow
import vn.thongkedonhang.app.ui.theme.PrimaryYellowContainer
import vn.thongkedonhang.app.ui.theme.TextPrimaryDark
import vn.thongkedonhang.app.ui.theme.ThongKeDonHangTheme

enum class AppScreen(val title: String, val navLabel: String, val icon: ImageVector) {
    OVERVIEW("Thống kê đơn hàng", "Tổng quan", Icons.Default.Dashboard),
    ORDER_LIST("Danh sách & Tìm kiếm đơn", "Đơn hàng", Icons.Default.ReceiptLong),
    ADD_ORDER("Thêm đơn hàng mới", "Thêm đơn", Icons.Default.AddCircle),
    ORDER_GROUPS("Quản lý Nhóm đơn gộp", "Đơn gộp", Icons.Default.FolderSpecial),
    CALENDAR_STATS("Lịch & Thống kê ngày", "Lịch ngày", Icons.Default.CalendarMonth),
    TOTAL_REPORT("Báo cáo Tổng tiền", "Báo cáo", Icons.Default.Assessment),
    BACKUP_RESTORE("Sao lưu & Khôi phục", "Sao lưu", Icons.Default.Backup),
    ORDER_DETAIL("Chi tiết đơn hàng", "Chi tiết", Icons.Default.ReceiptLong)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as ThongKeDonHangApp
        setContent {
            ThongKeDonHangTheme {
                val mainViewModel: MainViewModel = viewModel(
                    factory = MainViewModel.Factory(app.repository)
                )
                ThongKeDonHangRoot(
                    viewModel = mainViewModel,
                    app = app
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThongKeDonHangRoot(
    viewModel: MainViewModel,
    app: ThongKeDonHangApp
) {
    val snackbarHostState = remember { SnackbarHostState() }

    var currentScreen by remember { mutableStateOf(AppScreen.OVERVIEW) }
    var selectedOrderIdForDetail by remember { mutableStateOf<String?>(null) }
    var preselectedGroupIdForAdd by remember { mutableStateOf<String?>(null) }
    var startAddInScanMode by remember { mutableStateOf(true) }
    var highlightedGroupId by remember { mutableStateOf<String?>(null) }

    val selectedDateIso by viewModel.selectedDate.collectAsState()
    val dailyStats by viewModel.selectedDateStats.collectAsState()
    val dailyOrders by viewModel.ordersForSelectedDate.collectAsState()
    val rangeStats by viewModel.reportRangeStats.collectAsState()
    val ordersInRange by viewModel.ordersInReportRange.collectAsState()
    val allOrders by viewModel.allOrders.collectAsState()
    val filteredOrders by viewModel.filteredOrderList.collectAsState()
    val searchSuffixQuery by viewModel.searchSuffixQuery.collectAsState()
    val searchScopeMode by viewModel.searchScopeMode.collectAsState()
    val statusFilter by viewModel.statusFilter.collectAsState()
    val orderCountPerDate by viewModel.orderCountPerDate.collectAsState()
    val allGroups by viewModel.allGroupSummaries.collectAsState()
    val duplicatePrompt by viewModel.duplicateOrderPrompt.collectAsState()
    val reportStartDate by viewModel.reportStartDate.collectAsState()
    val reportEndDate by viewModel.reportEndDate.collectAsState()
    val reportRangeError by viewModel.reportRangeError.collectAsState()
    val pendingRestorePreview by viewModel.pendingRestorePreview.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.snackbarMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val bottomTabs = listOf(
        AppScreen.OVERVIEW,
        AppScreen.ORDER_LIST,
        AppScreen.ADD_ORDER,
        AppScreen.ORDER_GROUPS,
        AppScreen.CALENDAR_STATS
    )

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = currentScreen.title,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        color = TextPrimaryDark
                    )
                },
                actions = {
                    IconButton(onClick = { currentScreen = AppScreen.TOTAL_REPORT }) {
                        Icon(
                            imageVector = Icons.Default.Assessment,
                            contentDescription = "Báo cáo tổng tiền",
                            tint = TextPrimaryDark
                        )
                    }
                    IconButton(onClick = { currentScreen = AppScreen.BACKUP_RESTORE }) {
                        Icon(
                            imageVector = Icons.Default.Backup,
                            contentDescription = "Sao lưu và khôi phục",
                            tint = TextPrimaryDark
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = PrimaryYellow,
                    titleContentColor = TextPrimaryDark
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color.White
            ) {
                bottomTabs.forEach { tab ->
                    val selected = currentScreen == tab
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            if (tab == AppScreen.ADD_ORDER) {
                                preselectedGroupIdForAdd = null
                                startAddInScanMode = true
                            }
                            currentScreen = tab
                        },
                        icon = {
                            Icon(imageVector = tab.icon, contentDescription = tab.navLabel)
                        },
                        label = {
                            Text(
                                text = tab.navLabel,
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TextPrimaryDark,
                            selectedTextColor = TextPrimaryDark,
                            indicatorColor = PrimaryYellowContainer
                        )
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        containerColor = Color.White
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.OVERVIEW -> {
                    OverviewScreen(
                        selectedDateIso = selectedDateIso,
                        dailyStats = dailyStats,
                        rangeStats = rangeStats,
                        onPreviousDay = { viewModel.stepSelectedDate(-1) },
                        onNextDay = { viewModel.stepSelectedDate(1) },
                        onOpenCalendar = { currentScreen = AppScreen.CALENDAR_STATS },
                        onOpenOrderListWithFilter = { status ->
                            viewModel.updateSearchScopeMode(SearchScopeMode.SELECTED_DATE)
                            viewModel.updateStatusFilter(status)
                            currentScreen = AppScreen.ORDER_LIST
                        },
                        onNavigateToAddOrder = { scanMode ->
                            preselectedGroupIdForAdd = null
                            startAddInScanMode = scanMode
                            currentScreen = AppScreen.ADD_ORDER
                        },
                        onNavigateToGroups = {
                            highlightedGroupId = null
                            currentScreen = AppScreen.ORDER_GROUPS
                        },
                        onNavigateToReport = { currentScreen = AppScreen.TOTAL_REPORT },
                        onNavigateToBackup = { currentScreen = AppScreen.BACKUP_RESTORE }
                    )
                }

                AppScreen.ORDER_LIST -> {
                    OrderListScreen(
                        selectedDateIso = selectedDateIso,
                        dailyOrderCount = dailyStats.totalOrders,
                        orders = filteredOrders,
                        searchSuffixQuery = searchSuffixQuery,
                        searchScopeMode = searchScopeMode,
                        statusFilter = statusFilter,
                        onSearchQueryChange = viewModel::updateSearchSuffixQuery,
                        onSearchScopeChange = viewModel::updateSearchScopeMode,
                        onStatusFilterChange = viewModel::updateStatusFilter,
                        onPreviousDay = { viewModel.stepSelectedDate(-1) },
                        onNextDay = { viewModel.stepSelectedDate(1) },
                        onOpenCalendar = { currentScreen = AppScreen.CALENDAR_STATS },
                        onOrderClick = { orderId ->
                            selectedOrderIdForDetail = orderId
                            currentScreen = AppScreen.ORDER_DETAIL
                        },
                        onQuickStatusChange = { orderId, newSt ->
                            viewModel.changeOrderStatus(orderId, newSt)
                        },
                        onOpenGroupClick = { groupId ->
                            highlightedGroupId = groupId
                            currentScreen = AppScreen.ORDER_GROUPS
                        },
                        onAddOrderClick = {
                            preselectedGroupIdForAdd = null
                            startAddInScanMode = false
                            currentScreen = AppScreen.ADD_ORDER
                        },
                        resolvePhotoFile = viewModel::resolvePhotoFile
                    )
                }

                AppScreen.ADD_ORDER -> {
                    AddOrderScreen(
                        selectedDateIso = selectedDateIso,
                        currentDailyCount = dailyStats.totalOrders,
                        groups = allGroups,
                        preselectedGroupId = preselectedGroupIdForAdd,
                        startInScanMode = startAddInScanMode,
                        duplicatePrompt = duplicatePrompt,
                        photoStorageManager = app.photoStorageManager,
                        onSaveOrder = { code, amountStr, st, grpId, note, uris ->
                            viewModel.createNewOrder(
                                orderCode = code,
                                amountInput = amountStr,
                                status = st,
                                statDate = selectedDateIso,
                                groupId = grpId,
                                note = note,
                                photoUris = uris,
                                onSuccess = { created ->
                                    selectedOrderIdForDetail = created.id
                                    currentScreen = AppScreen.ORDER_DETAIL
                                }
                            )
                        },
                        onOpenExistingDuplicateOrder = { existingId ->
                            selectedOrderIdForDetail = existingId
                            currentScreen = AppScreen.ORDER_DETAIL
                        },
                        onDismissDuplicatePrompt = viewModel::clearDuplicatePrompt,
                        onShowMessage = viewModel::emitSnackbar
                    )
                }

                AppScreen.ORDER_DETAIL -> {
                    val currentOrder = allOrders.firstOrNull { it.id == selectedOrderIdForDetail }
                    OrderDetailScreen(
                        order = currentOrder,
                        groups = allGroups,
                        photoStorageManager = app.photoStorageManager,
                        onBack = { currentScreen = AppScreen.ORDER_LIST },
                        onStatusChange = { newStatus ->
                            currentOrder?.let { viewModel.changeOrderStatus(it.id, newStatus) }
                        },
                        onSaveEdits = { newCode, newAmount, newStatus, newGroupId, newNote ->
                            currentOrder?.let {
                                viewModel.saveOrderEdits(
                                    orderId = it.id,
                                    newCode = newCode,
                                    newAmountInput = newAmount,
                                    newStatus = newStatus,
                                    newGroupId = newGroupId,
                                    newNote = newNote
                                )
                            }
                        },
                        onAddPhoto = { uri ->
                            currentOrder?.let { viewModel.addPhotoToOrder(it.id, uri) }
                        },
                        onReplacePhoto = { oldPhotoId, newUri ->
                            currentOrder?.let { viewModel.replacePhotoInOrder(it.id, oldPhotoId, newUri) }
                        },
                        onDeletePhoto = { photoId ->
                            currentOrder?.let { viewModel.deletePhotoFromOrder(it.id, photoId) }
                        },
                        onDeleteOrder = {
                            currentOrder?.let {
                                viewModel.deleteOrder(it.id) {
                                    currentScreen = AppScreen.ORDER_LIST
                                }
                            }
                        },
                        onOpenGroup = { groupId ->
                            highlightedGroupId = groupId
                            currentScreen = AppScreen.ORDER_GROUPS
                        },
                        onShowMessage = viewModel::emitSnackbar
                    )
                }

                AppScreen.ORDER_GROUPS -> {
                    OrderGroupScreen(
                        groups = allGroups,
                        allOrders = allOrders,
                        initialHighlightedGroupId = highlightedGroupId,
                        onCreateGroup = { name, note ->
                            viewModel.createGroup(name, note) { createdId ->
                                highlightedGroupId = createdId
                            }
                        },
                        onRenameGroup = viewModel::renameGroup,
                        onDeleteGroupKeepOrders = viewModel::deleteGroupKeepingOrders,
                        onAssignOrderToGroup = viewModel::assignOrderToGroup,
                        onAddNewOrderDirectlyInGroup = { groupId ->
                            preselectedGroupIdForAdd = groupId
                            startAddInScanMode = false
                            currentScreen = AppScreen.ADD_ORDER
                        },
                        onOpenOrderDetail = { orderId ->
                            selectedOrderIdForDetail = orderId
                            currentScreen = AppScreen.ORDER_DETAIL
                        }
                    )
                }

                AppScreen.CALENDAR_STATS -> {
                    CalendarStatsScreen(
                        selectedDateIso = selectedDateIso,
                        dailyStats = dailyStats,
                        dailyOrders = dailyOrders,
                        orderCountPerDate = orderCountPerDate,
                        onSelectDate = viewModel::selectDate,
                        onPreviousDay = { viewModel.stepSelectedDate(-1) },
                        onNextDay = { viewModel.stepSelectedDate(1) },
                        onOrderClick = { orderId ->
                            selectedOrderIdForDetail = orderId
                            currentScreen = AppScreen.ORDER_DETAIL
                        },
                        onQuickStatusChange = viewModel::changeOrderStatus,
                        onOpenGroupClick = { groupId ->
                            highlightedGroupId = groupId
                            currentScreen = AppScreen.ORDER_GROUPS
                        },
                        resolvePhotoFile = viewModel::resolvePhotoFile
                    )
                }

                AppScreen.TOTAL_REPORT -> {
                    TotalReportScreen(
                        selectedDateIso = selectedDateIso,
                        dailyStats = dailyStats,
                        reportStartDateIso = reportStartDate,
                        reportEndDateIso = reportEndDate,
                        reportRangeError = reportRangeError,
                        rangeStats = rangeStats,
                        ordersInRange = ordersInRange,
                        onApplyDateRange = viewModel::setReportDateRange
                    )
                }

                AppScreen.BACKUP_RESTORE -> {
                    BackupRestoreScreen(
                        totalOrdersInDb = allOrders.size,
                        totalGroupsInDb = allGroups.size,
                        pendingRestorePreview = pendingRestorePreview,
                        onExportBackupUri = viewModel::exportBackupToUri,
                        onSelectRestoreUriForValidation = viewModel::inspectBackupBeforeRestore,
                        onConfirmRestore = viewModel::confirmAndExecuteRestore,
                        onCancelRestore = viewModel::cancelPendingRestore
                    )
                }
            }
        }
    }
}
