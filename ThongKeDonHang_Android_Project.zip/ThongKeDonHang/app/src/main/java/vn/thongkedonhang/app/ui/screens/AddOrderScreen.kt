package vn.thongkedonhang.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import vn.thongkedonhang.app.data.storage.PhotoStorageManager
import vn.thongkedonhang.app.domain.model.OrderConstants
import vn.thongkedonhang.app.domain.model.OrderGroupSummary
import vn.thongkedonhang.app.domain.model.OrderStatus
import vn.thongkedonhang.app.domain.util.OrderCalculator
import vn.thongkedonhang.app.ui.DuplicateOrderPrompt
import vn.thongkedonhang.app.ui.components.CameraBarcodeScannerSection
import vn.thongkedonhang.app.ui.components.DuplicateOrderWarningDialog
import vn.thongkedonhang.app.ui.components.StatusSelectorGroup
import vn.thongkedonhang.app.ui.theme.CardGrayBorder
import vn.thongkedonhang.app.ui.theme.PrimaryYellow
import vn.thongkedonhang.app.ui.theme.PrimaryYellowContainer
import vn.thongkedonhang.app.ui.theme.PrimaryYellowDark
import vn.thongkedonhang.app.ui.theme.StatusCancelledRed
import vn.thongkedonhang.app.ui.theme.TextPrimaryDark
import vn.thongkedonhang.app.ui.theme.TextSecondaryGray

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddOrderScreen(
    selectedDateIso: String,
    currentDailyCount: Int,
    groups: List<OrderGroupSummary>,
    preselectedGroupId: String?,
    startInScanMode: Boolean,
    duplicatePrompt: DuplicateOrderPrompt?,
    photoStorageManager: PhotoStorageManager,
    onSaveOrder: (
        orderCode: String,
        amountInput: String,
        status: OrderStatus,
        groupId: String?,
        note: String,
        photoUris: List<Uri>
    ) -> Unit,
    onOpenExistingDuplicateOrder: (String) -> Unit,
    onDismissDuplicatePrompt: () -> Unit,
    onShowMessage: (String) -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    var useCameraScanner by remember(startInScanMode) { mutableStateOf(startInScanMode) }
    var orderCode by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("0") }
    var selectedStatus by remember { mutableStateOf(OrderStatus.DELIVERED_SUCCESS) }
    var selectedGroupId by remember(preselectedGroupId) { mutableStateOf(preselectedGroupId) }
    var noteText by remember { mutableStateOf("") }
    val selectedPhotoUris = remember { mutableStateListOf<Uri>() }

    // Lưu Uri tạm khi chụp ảnh bằng Camera
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && pendingCameraUri != null) {
            if (selectedPhotoUris.size < OrderConstants.MAX_PHOTOS_PER_ORDER) {
                selectedPhotoUris.add(pendingCameraUri!!)
            } else {
                onShowMessage("Mỗi đơn hàng chỉ được đính kèm tối đa 3 ảnh.")
            }
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            if (selectedPhotoUris.size < OrderConstants.MAX_PHOTOS_PER_ORDER) {
                selectedPhotoUris.add(uri)
            } else {
                onShowMessage("Mỗi đơn hàng chỉ được đính kèm tối đa 3 ảnh.")
            }
        }
    }

    if (duplicatePrompt != null) {
        DuplicateOrderWarningDialog(
            message = duplicatePrompt.message,
            existingOrderCode = duplicatePrompt.existingOrder.orderCode,
            onOpenExistingOrder = {
                val id = duplicatePrompt.existingOrder.id
                onDismissDuplicatePrompt()
                onOpenExistingDuplicateOrder(id)
            },
            onDismiss = onDismissDuplicatePrompt
        )
    }

    val isDailyLimitReached = currentDailyCount >= OrderConstants.MAX_ORDERS_PER_DAY

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Thông báo ngày thống kê & hạn mức 100 đơn/ngày
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isDailyLimitReached) Color(0xFFFEE2E2) else PrimaryYellowContainer
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Thêm đơn vào ngày: ${OrderCalculator.formatIsoToVnDate(selectedDateIso)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextPrimaryDark
                )
                Text(
                    text = if (isDailyLimitReached) {
                        "Ngày này đã đạt giới hạn 100 đơn (100/100). Không thể thêm đơn thứ 101."
                    } else {
                        "Số đơn hiện tại trong ngày: $currentDailyCount/100 (Còn lại ${100 - currentDailyCount} đơn)"
                    },
                    fontSize = 13.sp,
                    fontWeight = if (isDailyLimitReached) FontWeight.Bold else FontWeight.Normal,
                    color = if (isDailyLimitReached) StatusCancelledRed else TextSecondaryGray
                )
            }
        }

        // Chuyển đổi giữa Cách 1: Quét bằng Camera và Cách 2: Nhập thủ công (Phần 3)
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            FilterChip(
                selected = useCameraScanner,
                onClick = { useCameraScanner = true },
                label = { Text("Cách 1: Quét Camera QR/Mã vạch", fontWeight = FontWeight.Bold) },
                leadingIcon = {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PrimaryYellow
                ),
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = !useCameraScanner,
                onClick = { useCameraScanner = false },
                label = { Text("Cách 2: Nhập tay", fontWeight = FontWeight.Bold) },
                leadingIcon = {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PrimaryYellow
                )
            )
        }

        // Khung Quét CameraX + ML Kit nếu đang bật chế độ Quét
        if (useCameraScanner) {
            CameraBarcodeScannerSection(
                onCodeConfirmed = { scanned ->
                    orderCode = scanned
                    onShowMessage("Đã điền mã đơn vừa quét: $scanned")
                }
            )
        }

        // Ô nhập Mã đơn hàng + Nút dán từ Clipboard (Phần 3)
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "1. Mã đơn hàng (Hỗ trợ cả chữ và số)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = orderCode,
                        onValueChange = { orderCode = it },
                        placeholder = { Text("Nhập hoặc quét mã vận đơn (VD: SPXVN09871234)") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = {
                            val clipText = clipboardManager.getText()?.text?.trim()
                            if (!clipText.isNullOrEmpty()) {
                                orderCode = clipText
                                onShowMessage("Đã dán mã từ bộ nhớ tạm: $clipText")
                            } else {
                                onShowMessage("Bộ nhớ tạm (Clipboard) đang trống.")
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(54.dp)
                    ) {
                        Icon(Icons.Default.ContentPaste, contentDescription = "Dán mã")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Dán")
                    }
                }
                if (orderCode.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "4 ký tự cuối để tìm nhanh: ${OrderCalculator.extractSuffix4(orderCode)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = PrimaryYellowDark
                    )
                }
            }
        }

        // Ô nhập Giá tiền của đơn (Phần 4)
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                val parsedAmount = OrderCalculator.parseAmountVnd(amountText)
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "2. Giá tiền đơn hàng (VNĐ)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimaryDark
                    )
                    Text(
                        text = "Hiển thị: ${OrderCalculator.formatVnd(parsedAmount)}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        color = PrimaryYellowDark
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { raw ->
                        amountText = raw.filter { it.isDigit() }
                    },
                    placeholder = { Text("Mặc định 0 đồng nếu để trống") },
                    suffix = { Text("₫", fontWeight = FontWeight.Bold) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                // Gợi ý nhập nhanh mệnh giá phổ biến
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    listOf(0L, 50_000L, 100_000L, 150_000L, 250_000L).forEach { quickVal ->
                        OutlinedButton(
                            onClick = { amountText = quickVal.toString() },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (quickVal == 0L) "0đ" else "${quickVal / 1000}k",
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Chọn 1 trong 3 Trạng thái đơn hàng (Phần 6)
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "3. Trạng thái đơn hàng",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(8.dp))
                StatusSelectorGroup(
                    selectedStatus = selectedStatus,
                    onStatusSelected = { selectedStatus = it }
                )
            }
        }

        // Đính kèm tối đa 3 hình ảnh (Phần 5)
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "4. Ảnh đính kèm (${selectedPhotoUris.size}/3 ảnh)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimaryDark
                    )
                    if (selectedPhotoUris.size >= OrderConstants.MAX_PHOTOS_PER_ORDER) {
                        Text(
                            text = "Đã đủ tối đa 3 ảnh",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusCancelledRed
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val canAddMore = selectedPhotoUris.size < OrderConstants.MAX_PHOTOS_PER_ORDER
                    OutlinedButton(
                        onClick = {
                            if (!canAddMore) {
                                onShowMessage("Đã đủ 3 ảnh. Không thể thêm ảnh thứ 4.")
                            } else {
                                val (_, uri) = photoStorageManager.createTempCameraCaptureUri()
                                pendingCameraUri = uri
                                takePictureLauncher.launch(uri)
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Chụp ảnh")
                    }

                    OutlinedButton(
                        onClick = {
                            if (!canAddMore) {
                                onShowMessage("Đã đủ 3 ảnh. Không thể thêm ảnh thứ 4.")
                            } else {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Chọn từ thư viện")
                    }
                }

                if (selectedPhotoUris.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        selectedPhotoUris.forEachIndexed { idx, uri ->
                            Box(modifier = Modifier.size(88.dp)) {
                                AsyncImage(
                                    model = uri,
                                    contentDescription = "Ảnh xem trước ${idx + 1}",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(10.dp))
                                        .border(1.dp, CardGrayBorder, RoundedCornerShape(10.dp))
                                )
                                Surface(
                                    color = StatusCancelledRed,
                                    shape = CircleShape,
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .size(24.dp)
                                        .clickable { selectedPhotoUris.removeAt(idx) }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Xóa ảnh",
                                        tint = Color.White,
                                        modifier = Modifier.padding(3.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Chọn Nhóm đơn gộp (Tùy chọn - Phần 8) & Ghi chú
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "5. Nhóm đơn gộp & Ghi chú (Tùy chọn)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(8.dp))

                var groupDropdownExpanded by remember { mutableStateOf(false) }
                val selectedGroupName = groups.firstOrNull { it.groupId == selectedGroupId }?.groupName
                    ?: "Không thuộc nhóm nào (Đơn lẻ)"

                ExposedDropdownMenuBox(
                    expanded = groupDropdownExpanded,
                    onExpandedChange = { groupDropdownExpanded = !groupDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedGroupName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Nhóm đơn gộp") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = groupDropdownExpanded)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = groupDropdownExpanded,
                        onDismissRequest = { groupDropdownExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Không thuộc nhóm nào (Đơn lẻ)") },
                            onClick = {
                                selectedGroupId = null
                                groupDropdownExpanded = false
                            }
                        )
                        groups.forEach { grp ->
                            DropdownMenuItem(
                                text = { Text("${grp.groupName} (${grp.orders.size} đơn)") },
                                onClick = {
                                    selectedGroupId = grp.groupId
                                    groupDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("Ghi chú đơn hàng (nếu có)") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Nút Lưu đơn hàng lớn dễ bấm bằng 1 tay
        Button(
            onClick = {
                onSaveOrder(
                    orderCode,
                    amountText,
                    selectedStatus,
                    selectedGroupId,
                    noteText,
                    selectedPhotoUris.toList()
                )
            },
            enabled = !isDailyLimitReached,
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryYellow),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Icon(Icons.Default.Save, contentDescription = null, tint = TextPrimaryDark)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isDailyLimitReached) {
                    "Đã đạt giới hạn 100 đơn trong ngày"
                } else {
                    "LƯU ĐƠN HÀNG"
                },
                color = TextPrimaryDark,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
