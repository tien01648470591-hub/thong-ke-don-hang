package vn.thongkedonhang.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import vn.thongkedonhang.app.domain.model.OrderGroupSummary
import vn.thongkedonhang.app.domain.model.OrderItem
import vn.thongkedonhang.app.domain.util.OrderCalculator
import vn.thongkedonhang.app.ui.components.StatusBadge
import vn.thongkedonhang.app.ui.theme.CardGrayBorder
import vn.thongkedonhang.app.ui.theme.PrimaryYellow
import vn.thongkedonhang.app.ui.theme.PrimaryYellowContainer
import vn.thongkedonhang.app.ui.theme.PrimaryYellowDark
import vn.thongkedonhang.app.ui.theme.SoftCreamSurface
import vn.thongkedonhang.app.ui.theme.StatusCancelledRed
import vn.thongkedonhang.app.ui.theme.StatusSuccessGreen
import vn.thongkedonhang.app.ui.theme.StatusWaitingYellow
import vn.thongkedonhang.app.ui.theme.TextPrimaryDark
import vn.thongkedonhang.app.ui.theme.TextSecondaryGray

/**
 * Trang Quản lý Nhóm đơn gộp (Phần 8):
 * - Mỗi nhóm có: Mã nhóm riêng, Tên nhóm/ghi chú, Ngày tạo nhóm, Danh sách mã đơn thuộc nhóm,
 *   Tổng số mã đơn trong nhóm, Tổng giá trị của nhóm (bao gồm cả đơn hủy), Tổng giá trị theo từng trạng thái.
 * - Đầy đủ thao tác: Tạo nhóm mới, Thêm đơn đã có vào nhóm, Thêm đơn mới trực tiếp trong nhóm,
 *   Xem toàn bộ mã đơn trong nhóm, Chuyển đơn sang nhóm khác, Tách đơn khỏi nhóm, Đổi tên nhóm,
 *   Xóa nhóm mà không xóa các đơn bên trong.
 */
@Composable
fun OrderGroupScreen(
    groups: List<OrderGroupSummary>,
    allOrders: List<OrderItem>,
    initialHighlightedGroupId: String?,
    onCreateGroup: (groupName: String, note: String) -> Unit,
    onRenameGroup: (groupId: String, newName: String, newNote: String) -> Unit,
    onDeleteGroupKeepOrders: (groupId: String) -> Unit,
    onAssignOrderToGroup: (orderId: String, groupId: String?) -> Unit,
    onAddNewOrderDirectlyInGroup: (groupId: String) -> Unit,
    onOpenOrderDetail: (orderId: String) -> Unit
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var groupToEdit by remember { mutableStateOf<OrderGroupSummary?>(null) }
    var groupToDelete by remember { mutableStateOf<OrderGroupSummary?>(null) }
    var groupToAddExistingOrder by remember { mutableStateOf<OrderGroupSummary?>(null) }
    var expandedGroupId by remember(initialHighlightedGroupId) {
        mutableStateOf(initialHighlightedGroupId ?: groups.firstOrNull()?.groupId)
    }

    LaunchedEffect(initialHighlightedGroupId) {
        if (initialHighlightedGroupId != null) {
            expandedGroupId = initialHighlightedGroupId
        }
    }

    // Hộp thoại Tạo nhóm mới
    if (showCreateDialog) {
        var newName by remember { mutableStateOf("") }
        var newNote by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Tạo nhóm đơn gộp mới", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Nhập tên nhận diện nhóm (ví dụ: Khách A, Nhóm 01, Chị Lan...). Không bắt buộc nhập thông tin cá nhân.",
                        fontSize = 13.sp,
                        color = TextSecondaryGray
                    )
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Tên nhóm đơn gộp") },
                        placeholder = { Text("VD: Khách A hoặc Nhóm 01") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newNote,
                        onValueChange = { newNote = it },
                        label = { Text("Ghi chú nhận diện (tùy chọn)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCreateGroup(newName, newNote)
                        showCreateDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryYellow)
                ) {
                    Text("Tạo nhóm", color = TextPrimaryDark, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Hộp thoại Đổi tên nhóm
    if (groupToEdit != null) {
        val target = groupToEdit!!
        var editedName by remember(target.groupId) { mutableStateOf(target.groupName) }
        var editedNote by remember(target.groupId) { mutableStateOf(target.note) }
        AlertDialog(
            onDismissRequest = { groupToEdit = null },
            title = { Text("Đổi tên / Sửa ghi chú nhóm", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editedName,
                        onValueChange = { editedName = it },
                        label = { Text("Tên nhóm") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editedNote,
                        onValueChange = { editedNote = it },
                        label = { Text("Ghi chú") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRenameGroup(target.groupId, editedName, editedNote)
                        groupToEdit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryYellow)
                ) {
                    Text("Lưu thay đổi", color = TextPrimaryDark, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { groupToEdit = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Hộp thoại Xác nhận xóa nhóm (Không xóa các đơn bên trong)
    if (groupToDelete != null) {
        val target = groupToDelete!!
        AlertDialog(
            onDismissRequest = { groupToDelete = null },
            title = { Text("Xóa nhóm đơn gộp?", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Bạn muốn xóa nhóm "${target.groupName}" (${target.groupCode})?

Lưu ý: Tất cả ${target.orders.size} đơn hàng bên trong nhóm sẽ KHÔNG bị xóa mà chỉ tách về trạng thái đơn lẻ."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteGroupKeepOrders(target.groupId)
                        groupToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusCancelledRed)
                ) {
                    Text("Xóa nhóm (Giữ đơn)", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { groupToDelete = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Hộp thoại Thêm một mã đơn đã có vào nhóm
    if (groupToAddExistingOrder != null) {
        val targetGroup = groupToAddExistingOrder!!
        val availableOrders = allOrders.filter { it.groupId != targetGroup.groupId }
        var searchFilter by remember { mutableStateOf("") }
        val filteredAvailable = availableOrders.filter {
            searchFilter.isBlank() ||
                it.orderCode.contains(searchFilter.trim(), ignoreCase = true) ||
                OrderCalculator.matchesSuffixQuery(it.orderCode, searchFilter)
        }

        AlertDialog(
            onDismissRequest = { groupToAddExistingOrder = null },
            title = {
                Text(
                    text = "Thêm đơn đã có vào "${targetGroup.groupName}"",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = searchFilter,
                        onValueChange = { searchFilter = it },
                        placeholder = { Text("Tìm mã đơn hoặc 4 số cuối...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    if (filteredAvailable.isEmpty()) {
                        Text(
                            text = "Không có đơn hàng nào khả dụng để thêm vào nhóm này.",
                            fontSize = 13.sp,
                            color = TextSecondaryGray
                        )
                    } else {
                        LazyColumn(modifier = Modifier.height(260.dp)) {
                            items(filteredAvailable, key = { it.id }) { ord ->
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, CardGrayBorder),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clickable {
                                            onAssignOrderToGroup(ord.id, targetGroup.groupId)
                                            groupToAddExistingOrder = null
                                        }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.padding(10.dp)
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = ord.orderCode,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            Text(
                                                text = "${OrderCalculator.formatIsoToVnDate(ord.statDate)} • ${OrderCalculator.formatVnd(ord.amountVnd)}",
                                                fontSize = 12.sp,
                                                color = TextSecondaryGray
                                            )
                                            if (!ord.groupName.isNullOrBlank()) {
                                                Text(
                                                    text = "Đang ở nhóm: ${ord.groupName} (Sẽ chuyển sang nhóm này)",
                                                    fontSize = 11.sp,
                                                    color = PrimaryYellowDark
                                                )
                                            }
                                        }
                                        Text(
                                            text = "+ Gộp",
                                            fontWeight = FontWeight.Bold,
                                            color = PrimaryYellowDark
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { groupToAddExistingOrder = null }) {
                    Text("Đóng")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Quản lý Nhóm đơn gộp",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = TextPrimaryDark
                )
                Text(
                    text = "Gom nhiều mã đơn của cùng một khách/người nhận",
                    fontSize = 12.sp,
                    color = TextSecondaryGray
                )
            }

            Button(
                onClick = { showCreateDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryYellow),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = TextPrimaryDark)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Tạo nhóm mới", color = TextPrimaryDark, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (groups.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FolderSpecial,
                        contentDescription = null,
                        tint = PrimaryYellow,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Chưa có nhóm đơn gộp nào.",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "Bấm "Tạo nhóm mới" để gộp nhiều mã đơn của cùng một người.",
                        fontSize = 13.sp,
                        color = TextSecondaryGray
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(groups, key = { it.groupId }) { grp ->
                    val isExpanded = expandedGroupId == grp.groupId
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(
                            if (isExpanded) 2.dp else 1.dp,
                            if (isExpanded) PrimaryYellow else CardGrayBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            // Header của nhóm
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        expandedGroupId = if (isExpanded) null else grp.groupId
                                    }
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.FolderSpecial,
                                            contentDescription = null,
                                            tint = PrimaryYellowDark,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = grp.groupName,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 17.sp,
                                            color = TextPrimaryDark
                                        )
                                    }
                                    Text(
                                        text = "Mã nhóm: ${grp.groupCode} • Ngày tạo: ${OrderCalculator.formatIsoToVnDate(grp.createdDate)}",
                                        fontSize = 12.sp,
                                        color = TextSecondaryGray
                                    )
                                    if (grp.note.isNotBlank()) {
                                        Text(
                                            text = "Ghi chú: ${grp.note}",
                                            fontSize = 12.sp,
                                            color = TextSecondaryGray
                                        )
                                    }
                                }

                                Row {
                                    IconButton(onClick = { groupToEdit = grp }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Đổi tên nhóm")
                                    }
                                    IconButton(onClick = { groupToDelete = grp }) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Xóa nhóm",
                                            tint = StatusCancelledRed
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Thống kê tổng số đơn & tổng giá trị của nhóm (Bao gồm cả đơn hủy - Phần 8)
                            Surface(
                                color = PrimaryYellowContainer.copy(alpha = 0.55f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "Tổng số mã đơn: ${grp.stats.totalOrders} đơn",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = "Tổng giá trị nhóm: ${OrderCalculator.formatVnd(grp.stats.totalAllAmountVnd)}",
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 15.sp,
                                            color = PrimaryYellowDark
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    // Phân loại theo từng trạng thái (Tính riêng, không cộng trùng)
                                    Text(
                                        text = "• Giao thành công (${grp.stats.deliveredCount}): ${OrderCalculator.formatVnd(grp.stats.deliveredAmountVnd)}",
                                        fontSize = 12.sp,
                                        color = StatusSuccessGreen,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "• Chờ chuyển khoản (${grp.stats.waitingCount}): ${OrderCalculator.formatVnd(grp.stats.waitingAmountVnd)}",
                                        fontSize = 12.sp,
                                        color = StatusWaitingYellow,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "• Đã hủy (${grp.stats.cancelledCount}): ${OrderCalculator.formatVnd(grp.stats.cancelledAmountVnd)} (Vẫn tính trong tổng giá trị nhóm)",
                                        fontSize = 12.sp,
                                        color = StatusCancelledRed,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // 2 Nút thêm đơn vào nhóm: Thêm đơn đã có hoặc Tạo đơn mới trực tiếp trong nhóm
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedButton(
                                    onClick = { groupToAddExistingOrder = grp },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.AddCircleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Thêm đơn đã có", fontSize = 12.sp)
                                }

                                Button(
                                    onClick = { onAddNewOrderDirectlyInGroup(grp.groupId) },
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryYellow),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = TextPrimaryDark, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Tạo đơn mới trong nhóm",
                                        color = TextPrimaryDark,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            // Danh sách các mã đơn thuộc nhóm
                            if (grp.orders.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Danh sách mã đơn trong nhóm (${grp.orders.size} mã):",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = TextPrimaryDark
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    grp.orders.forEachIndexed { idx, memberOrder ->
                                        var showMoveMenu by remember { mutableStateOf(false) }
                                        val otherGroups = groups.filter { it.groupId != grp.groupId }

                                        Surface(
                                            color = SoftCreamSurface,
                                            shape = RoundedCornerShape(10.dp),
                                            border = BorderStroke(1.dp, CardGrayBorder),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { onOpenOrderDetail(memberOrder.id) }
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                modifier = Modifier.padding(10.dp)
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = "${idx + 1}. ${memberOrder.orderCode}",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 14.sp,
                                                        color = TextPrimaryDark
                                                    )
                                                    Text(
                                                        text = "Ngày gốc: ${OrderCalculator.formatIsoToVnDate(memberOrder.statDate)} • ${OrderCalculator.formatVnd(memberOrder.amountVnd)}",
                                                        fontSize = 12.sp,
                                                        color = TextSecondaryGray
                                                    )
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    StatusBadge(status = memberOrder.status)
                                                }

                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    // Chuyển đơn sang nhóm khác
                                                    if (otherGroups.isNotEmpty()) {
                                                        Box {
                                                            IconButton(onClick = { showMoveMenu = true }) {
                                                                Icon(
                                                                    imageVector = Icons.Default.DriveFileMove,
                                                                    contentDescription = "Chuyển nhóm",
                                                                    tint = PrimaryYellowDark
                                                                )
                                                            }
                                                            DropdownMenu(
                                                                expanded = showMoveMenu,
                                                                onDismissRequest = { showMoveMenu = false }
                                                            ) {
                                                                otherGroups.forEach { targetGrp ->
                                                                    DropdownMenuItem(
                                                                        text = { Text("Chuyển sang: ${targetGrp.groupName}") },
                                                                        onClick = {
                                                                            showMoveMenu = false
                                                                            onAssignOrderToGroup(
                                                                                memberOrder.id,
                                                                                targetGrp.groupId
                                                                            )
                                                                        }
                                                                    )
                                                                }
                                                            }
                                                        }
                                                    }

                                                    // Tách đơn khỏi nhóm
                                                    IconButton(
                                                        onClick = {
                                                            onAssignOrderToGroup(memberOrder.id, null)
                                                        }
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.LinkOff,
                                                            contentDescription = "Tách khỏi nhóm",
                                                            tint = StatusCancelledRed
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Nhóm này hiện chưa có mã đơn nào.",
                                    fontSize = 12.sp,
                                    color = TextSecondaryGray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
