package vn.thongkedonhang.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import vn.thongkedonhang.app.domain.model.OrderItem
import vn.thongkedonhang.app.domain.model.OrderStatus
import vn.thongkedonhang.app.domain.util.OrderCalculator
import vn.thongkedonhang.app.ui.SearchScopeMode
import vn.thongkedonhang.app.ui.components.DateNavigatorBar
import vn.thongkedonhang.app.ui.components.OrderRowCard
import vn.thongkedonhang.app.ui.components.foregroundColor
import vn.thongkedonhang.app.ui.theme.CardGrayBorder
import vn.thongkedonhang.app.ui.theme.PrimaryYellow
import vn.thongkedonhang.app.ui.theme.PrimaryYellowContainer
import vn.thongkedonhang.app.ui.theme.PrimaryYellowDark
import vn.thongkedonhang.app.ui.theme.TextPrimaryDark
import vn.thongkedonhang.app.ui.theme.TextSecondaryGray
import java.io.File

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OrderListScreen(
    selectedDateIso: String,
    dailyOrderCount: Int,
    orders: List<OrderItem>,
    searchSuffixQuery: String,
    searchScopeMode: SearchScopeMode,
    statusFilter: OrderStatus?,
    onSearchQueryChange: (String) -> Unit,
    onSearchScopeChange: (SearchScopeMode) -> Unit,
    onStatusFilterChange: (OrderStatus?) -> Unit,
    onPreviousDay: () -> Unit,
    onNextDay: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOrderClick: (String) -> Unit,
    onQuickStatusChange: (String, OrderStatus) -> Unit,
    onOpenGroupClick: (String) -> Unit,
    onAddOrderClick: () -> Unit,
    resolvePhotoFile: (String) -> File
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // 1. Thanh Tìm kiếm nổi bật bằng 4 số cuối ở đầu danh sách (Phần 9)
        OutlinedTextField(
            value = searchSuffixQuery,
            onValueChange = onSearchQueryChange,
            placeholder = {
                Text(
                    text = "Nhập 4 số cuối mã đơn để tìm kiếm",
                    fontSize = 14.sp,
                    color = TextSecondaryGray
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Tìm kiếm",
                    tint = PrimaryYellowDark
                )
            },
            trailingIcon = {
                if (searchSuffixQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Xóa tìm kiếm")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryYellowDark,
                unfocusedBorderColor = PrimaryYellow,
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // 2. Chọn phạm vi tìm kiếm (Trong ngày đang chọn / Trong khoảng ngày báo cáo / Tất cả)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            SearchScopeMode.entries.forEach { mode ->
                val selected = searchScopeMode == mode
                FilterChip(
                    selected = selected,
                    onClick = { onSearchScopeChange(mode) },
                    label = {
                        Text(
                            text = mode.label,
                            fontSize = 12.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryYellowContainer,
                        selectedLabelColor = TextPrimaryDark
                    )
                )
            }
        }

        // 3. Nếu đang xem theo ngày, hiển thị thanh điều hướng ngày
        if (searchScopeMode == SearchScopeMode.SELECTED_DATE) {
            Spacer(modifier = Modifier.height(6.dp))
            DateNavigatorBar(
                selectedDateIso = selectedDateIso,
                orderCountInDay = dailyOrderCount,
                onPreviousDay = onPreviousDay,
                onNextDay = onNextDay,
                onOpenCalendarScreen = onOpenCalendar
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 4. Lọc theo trạng thái (Tất cả / Giao thành công / Chờ CK / Hủy đơn)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            FilterChip(
                selected = statusFilter == null,
                onClick = { onStatusFilterChange(null) },
                label = { Text("Tất cả trạng thái", fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PrimaryYellow,
                    selectedLabelColor = TextPrimaryDark
                )
            )
            OrderStatus.entries.forEach { st ->
                val selected = statusFilter == st
                FilterChip(
                    selected = selected,
                    onClick = { onStatusFilterChange(if (selected) null else st) },
                    label = {
                        Text(
                            text = st.displayName,
                            fontSize = 12.sp,
                            color = if (selected) st.foregroundColor() else TextPrimaryDark
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Thanh tóm tắt kết quả hiện tại
        val currentTotalAmount = orders.sumOf { it.amountVnd }
        Surface(
            color = PrimaryYellowContainer.copy(alpha = 0.45f),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    text = if (searchSuffixQuery.isBlank()) {
                        "Hiển thị: ${orders.size} đơn hàng"
                    } else {
                        "Kết quả khớp đuôi "${searchSuffixQuery.trim()}": ${orders.size} đơn"
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimaryDark
                )
                Text(
                    text = "Tổng: ${OrderCalculator.formatVnd(currentTotalAmount)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryYellowDark
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 5. Danh sách đơn hàng hoặc Giao diện trống rõ ràng
        if (orders.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Inbox,
                        contentDescription = null,
                        tint = TextSecondaryGray,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (searchSuffixQuery.isNotBlank()) {
                            "Không tìm thấy đơn hàng nào có phần cuối khớp với "${searchSuffixQuery.trim()}"."
                        } else {
                            "Chưa có đơn hàng nào trong danh sách này."
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimaryDark
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onAddOrderClick,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryYellow)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = TextPrimaryDark)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Thêm đơn hàng mới", color = TextPrimaryDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                itemsIndexed(orders, key = { _, item -> item.id }) { index, order ->
                    OrderRowCard(
                        indexNumber = index + 1,
                        order = order,
                        resolvePhotoFile = resolvePhotoFile,
                        onOrderClick = { onOrderClick(order.id) },
                        onQuickStatusChange = { newStatus ->
                            onQuickStatusChange(order.id, newStatus)
                        },
                        onOpenGroupClick = { gId ->
                            onOpenGroupClick(gId)
                        }
                    )
                }
            }
        }
    }
}
