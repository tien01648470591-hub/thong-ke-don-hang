package vn.thongkedonhang.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import vn.thongkedonhang.app.data.local.entity.OrderEntity
import vn.thongkedonhang.app.data.local.entity.OrderGroupEntity
import vn.thongkedonhang.app.data.local.entity.OrderPhotoEntity
import vn.thongkedonhang.app.data.local.entity.OrderWithDetailsRelation
import vn.thongkedonhang.app.domain.model.OrderConstants

@Dao
interface OrderDao {

    // --- TRUY VẤN ĐƠN HÀNG THEO NGÀY & KHOẢNG NGÀY ---

    @Transaction
    @Query("SELECT * FROM orders WHERE stat_date = :statDate ORDER BY created_at_millis DESC")
    fun observeOrdersByDate(statDate: String): Flow<List<OrderWithDetailsRelation>>

    @Transaction
    @Query("SELECT * FROM orders WHERE stat_date = :statDate ORDER BY created_at_millis DESC")
    suspend fun getOrdersByDateOnce(statDate: String): List<OrderWithDetailsRelation>

    @Transaction
    @Query("SELECT * FROM orders WHERE stat_date BETWEEN :startDate AND :endDate ORDER BY stat_date DESC, created_at_millis DESC")
    fun observeOrdersInRange(startDate: String, endDate: String): Flow<List<OrderWithDetailsRelation>>

    @Transaction
    @Query("SELECT * FROM orders WHERE stat_date BETWEEN :startDate AND :endDate ORDER BY stat_date DESC, created_at_millis DESC")
    suspend fun getOrdersInRangeOnce(startDate: String, endDate: String): List<OrderWithDetailsRelation>

    @Transaction
    @Query("SELECT * FROM orders ORDER BY stat_date DESC, created_at_millis DESC")
    fun observeAllOrders(): Flow<List<OrderWithDetailsRelation>>

    @Transaction
    @Query("SELECT * FROM orders WHERE id = :orderId LIMIT 1")
    fun observeOrderById(orderId: String): Flow<OrderWithDetailsRelation?>

    @Transaction
    @Query("SELECT * FROM orders WHERE id = :orderId LIMIT 1")
    suspend fun getOrderByIdOnce(orderId: String): OrderWithDetailsRelation?

    // --- KIỂM TRA TRÙNG MÃ ĐƠN TRONG CÙNG NGÀY (PHẦN 3) ---

    @Transaction
    @Query("SELECT * FROM orders WHERE LOWER(order_code) = LOWER(:orderCode) AND stat_date = :statDate LIMIT 1")
    suspend fun findByCodeAndDate(orderCode: String, statDate: String): OrderWithDetailsRelation?

    // --- ĐẾM SỐ ĐƠN TRONG NGÀY ĐỂ KIỂM TRA GIỚI HẠN 100 ĐƠN/NGÀY (PHẦN 10) ---

    @Query("SELECT COUNT(*) FROM orders WHERE stat_date = :statDate")
    suspend fun countOrdersByDate(statDate: String): Int

    @Query("SELECT stat_date, COUNT(*) as cnt FROM orders GROUP BY stat_date")
    fun observeOrderCountPerDate(): Flow<List<DateOrderCount>>

    // --- TÌM KIẾM BẰNG 4 SỐ CUỐI (PHẦN 9) ---

    @Transaction
    @Query(
        "SELECT * FROM orders WHERE stat_date = :statDate AND LOWER(order_code) LIKE '%' || LOWER(:suffixQuery) ORDER BY created_at_millis DESC"
    )
    suspend fun searchBySuffixInDate(statDate: String, suffixQuery: String): List<OrderWithDetailsRelation>

    @Transaction
    @Query(
        "SELECT * FROM orders WHERE stat_date BETWEEN :startDate AND :endDate AND LOWER(order_code) LIKE '%' || LOWER(:suffixQuery) ORDER BY stat_date DESC, created_at_millis DESC"
    )
    suspend fun searchBySuffixInRange(
        startDate: String,
        endDate: String,
        suffixQuery: String
    ): List<OrderWithDetailsRelation>

    // --- THÊM / SỬA / ĐỔI TRẠNG THÁI / XÓA ĐƠN HÀNG ---

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertOrderRaw(order: OrderEntity)

    /**
     * Kiểm tra giới hạn 100 đơn/ngày ngay trong @Transaction ở tầng dữ liệu (Phần 10)
     * để tránh vượt giới hạn khi có thao tác đồng thời.
     */
    @Transaction
    suspend fun insertOrderWithDailyLimitCheck(
        order: OrderEntity,
        photos: List<OrderPhotoEntity>
    ): InsertOrderDbResult {
        val currentCount = countOrdersByDate(order.statDate)
        if (currentCount >= OrderConstants.MAX_ORDERS_PER_DAY) {
            return InsertOrderDbResult.DAILY_LIMIT_REACHED
        }
        val duplicate = findByCodeAndDate(order.orderCode, order.statDate)
        if (duplicate != null) {
            return InsertOrderDbResult.DUPLICATE_IN_SAME_DAY
        }
        if (photos.size > OrderConstants.MAX_PHOTOS_PER_ORDER) {
            return InsertOrderDbResult.PHOTO_LIMIT_EXCEEDED
        }
        insertOrderRaw(order)
        if (photos.isNotEmpty()) {
            insertPhotos(photos)
        }
        return InsertOrderDbResult.SUCCESS
    }

    @Update
    suspend fun updateOrder(order: OrderEntity)

    /**
     * Đổi trạng thái đơn (Phần 6 & Phần 7):
     * Chỉ cập nhật cột status và updated_at_millis.
     * Tuyệt đối giữ nguyên order_code, amount_vnd, stat_date và ảnh đính kèm.
     */
    @Query("UPDATE orders SET status = :newStatus, updated_at_millis = :updatedAt WHERE id = :orderId")
    suspend fun updateOrderStatusOnly(orderId: String, newStatus: String, updatedAt: Long)

    /**
     * Sửa giá tiền của đơn (Phần 4 & Phần 7):
     * Cập nhật ngay lập tức trong cơ sở dữ liệu.
     */
    @Query("UPDATE orders SET amount_vnd = :newAmountVnd, updated_at_millis = :updatedAt WHERE id = :orderId")
    suspend fun updateOrderAmountOnly(orderId: String, newAmountVnd: Long, updatedAt: Long)

    @Query("DELETE FROM orders WHERE id = :orderId")
    suspend fun deleteOrderById(orderId: String)

    // --- QUẢN LÝ ẢNH ĐÍNH KÈM (PHẦN 5 - TỐI ĐA 3 ẢNH/ĐƠN) ---

    @Query("SELECT * FROM order_photos WHERE order_id = :orderId ORDER BY position ASC")
    suspend fun getPhotosForOrder(orderId: String): List<OrderPhotoEntity>

    @Query("SELECT COUNT(*) FROM order_photos WHERE order_id = :orderId")
    suspend fun countPhotosForOrder(orderId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhotos(photos: List<OrderPhotoEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhoto(photo: OrderPhotoEntity)

    @Query("DELETE FROM order_photos WHERE photo_id = :photoId")
    suspend fun deletePhotoById(photoId: String)

    // --- QUẢN LÝ NHÓM ĐƠN GỘP (PHẦN 8) ---

    @Query("SELECT * FROM order_groups ORDER BY created_at_millis DESC")
    fun observeAllGroups(): Flow<List<OrderGroupEntity>>

    @Query("SELECT * FROM order_groups ORDER BY created_at_millis DESC")
    suspend fun getAllGroupsOnce(): List<OrderGroupEntity>

    @Query("SELECT * FROM order_groups WHERE group_id = :groupId LIMIT 1")
    suspend fun getGroupById(groupId: String): OrderGroupEntity?

    @Transaction
    @Query("SELECT * FROM orders WHERE group_id = :groupId ORDER BY created_at_millis DESC")
    fun observeOrdersByGroupId(groupId: String): Flow<List<OrderWithDetailsRelation>>

    @Transaction
    @Query("SELECT * FROM orders WHERE group_id = :groupId ORDER BY created_at_millis DESC")
    suspend fun getOrdersByGroupIdOnce(groupId: String): List<OrderWithDetailsRelation>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertGroup(group: OrderGroupEntity)

    @Query("UPDATE order_groups SET group_name = :newName, note = :newNote WHERE group_id = :groupId")
    suspend fun updateGroupNameAndNote(groupId: String, newName: String, newNote: String)

    /**
     * Gán hoặc chuyển đơn sang nhóm khác, hoặc tách đơn khỏi nhóm (groupId = null).
     * Mỗi đơn chỉ thuộc tối đa 1 nhóm tại cùng thời điểm.
     */
    @Query("UPDATE orders SET group_id = :groupId, updated_at_millis = :updatedAt WHERE id = :orderId")
    suspend fun assignOrderToGroup(orderId: String, groupId: String?, updatedAt: Long)

    @Query("UPDATE orders SET group_id = NULL, updated_at_millis = :updatedAt WHERE group_id = :groupId")
    suspend fun detachAllOrdersFromGroup(groupId: String, updatedAt: Long)

    @Query("DELETE FROM order_groups WHERE group_id = :groupId")
    suspend fun deleteGroupRow(groupId: String)

    /**
     * Xóa nhóm mà KHÔNG xóa các đơn bên trong (Phần 8).
     */
    @Transaction
    suspend fun deleteGroupKeepingOrders(groupId: String, updatedAt: Long) {
        detachAllOrdersFromGroup(groupId, updatedAt)
        deleteGroupRow(groupId)
    }

    // --- PHỤC VỤ SAO LƯU & KHÔI PHỤC TOÀN BỘ DỮ LIỆU (PHẦN 13) ---

    @Query("SELECT * FROM orders ORDER BY created_at_millis ASC")
    suspend fun getAllOrderEntitiesRaw(): List<OrderEntity>

    @Query("SELECT * FROM order_photos ORDER BY created_at_millis ASC")
    suspend fun getAllPhotoEntitiesRaw(): List<OrderPhotoEntity>

    @Query("DELETE FROM order_photos")
    suspend fun clearAllPhotos()

    @Query("DELETE FROM orders")
    suspend fun clearAllOrders()

    @Query("DELETE FROM order_groups")
    suspend fun clearAllGroups()

    @Transaction
    suspend fun replaceAllDataForRestore(
        groups: List<OrderGroupEntity>,
        orders: List<OrderEntity>,
        photos: List<OrderPhotoEntity>
    ) {
        clearAllPhotos()
        clearAllOrders()
        clearAllGroups()
        for (g in groups) {
            insertGroup(g)
        }
        for (o in orders) {
            insertOrderRaw(o)
        }
        if (photos.isNotEmpty()) {
            insertPhotos(photos)
        }
    }
}

data class DateOrderCount(
    val stat_date: String,
    val cnt: Int
)

enum class InsertOrderDbResult {
    SUCCESS,
    DAILY_LIMIT_REACHED,
    DUPLICATE_IN_SAME_DAY,
    PHOTO_LIMIT_EXCEEDED
}
