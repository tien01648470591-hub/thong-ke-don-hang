package vn.thongkedonhang.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Bảng lưu thông tin Đơn hàng (Phần 3, 4, 6, 7, 8, 9, 10).
 * Lưu ý quan trọng:
 * - Khoá ngoại group_id tham chiếu đến order_groups(group_id) với onDelete = ForeignKey.SET_NULL
 *   để khi xóa một nhóm đơn gộp, các đơn hàng bên trong KHÔNG bị xóa mà chỉ tách khỏi nhóm (Phần 8).
 * - Cột stat_date lưu ngày thống kê gốc (yyyy-MM-dd), đảm bảo giữ nguyên ngày thống kê gốc của từng mã
 *   kể cả khi gộp nhóm khác ngày hoặc chuyển sang xem ngày khác.
 */
@Entity(
    tableName = "orders",
    foreignKeys = [
        ForeignKey(
            entity = OrderGroupEntity::class,
            parentColumns = ["group_id"],
            childColumns = ["group_id"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["stat_date"]),
        Index(value = ["order_code", "stat_date"]),
        Index(value = ["code_suffix4"]),
        Index(value = ["group_id"]),
        Index(value = ["status"])
    ]
)
data class OrderEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "order_code")
    val orderCode: String,

    @ColumnInfo(name = "code_suffix4")
    val codeSuffix4: String,

    @ColumnInfo(name = "amount_vnd")
    val amountVnd: Long = 0L,

    @ColumnInfo(name = "status")
    val status: String,

    @ColumnInfo(name = "stat_date")
    val statDate: String, // yyyy-MM-dd

    @ColumnInfo(name = "created_at_millis")
    val createdAtMillis: Long,

    @ColumnInfo(name = "updated_at_millis")
    val updatedAtMillis: Long,

    @ColumnInfo(name = "group_id")
    val groupId: String? = null,

    @ColumnInfo(name = "note")
    val note: String = ""
)
