package vn.thongkedonhang.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import vn.thongkedonhang.app.data.backup.BackupPreviewInfo
import vn.thongkedonhang.app.domain.util.OrderCalculator
import vn.thongkedonhang.app.ui.theme.CardGrayBorder
import vn.thongkedonhang.app.ui.theme.PrimaryYellow
import vn.thongkedonhang.app.ui.theme.PrimaryYellowContainer
import vn.thongkedonhang.app.ui.theme.PrimaryYellowDark
import vn.thongkedonhang.app.ui.theme.StatusCancelledRed
import vn.thongkedonhang.app.ui.theme.StatusSuccessGreen
import vn.thongkedonhang.app.ui.theme.TextPrimaryDark
import vn.thongkedonhang.app.ui.theme.TextSecondaryGray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Trang Sao lưu và Khôi phục dữ liệu (Phần 13):
 * - Xuất bản sao lưu (.zip) chứa đầy đủ đơn hàng, nhóm đơn gộp và toàn bộ hình ảnh đính kèm.
 * - Kiểm tra tính hợp lệ của bản sao lưu trước khi khôi phục.
 * - Hiển thị hộp thoại xác nhận chi tiết trước khi thay thế dữ liệu hiện tại.
 */
@Composable
fun BackupRestoreScreen(
    totalOrdersInDb: Int,
    totalGroupsInDb: Int,
    pendingRestorePreview: Pair<Uri, BackupPreviewInfo>?,
    onExportBackupUri: (Uri) -> Unit,
    onSelectRestoreUriForValidation: (Uri) -> Unit,
    onConfirmRestore: () -> Unit,
    onCancelRestore: () -> Unit
) {
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri: Uri? ->
        if (uri != null) {
            onExportBackupUri(uri)
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            onSelectRestoreUriForValidation(uri)
        }
    }

    // Hộp thoại xác nhận trước khi khôi phục (Sau khi đã kiểm tra tệp ZIP hợp lệ)
    if (pendingRestorePreview != null) {
        val info = pendingRestorePreview.second
        val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
            .format(Date(info.createdAtMillis))

        AlertDialog(
            onDismissRequest = onCancelRestore,
            title = {
                Text(
                    text = "Xác nhận khôi phục bản sao lưu",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Bản sao lưu đã được kiểm tra HỢP LỆ:",
                        fontWeight = FontWeight.Bold,
                        color = StatusSuccessGreen
                    )
                    Text("• Thời điểm sao lưu: $dateStr")
                    Text("• Số lượng đơn hàng: ${info.totalOrders} đơn")
                    Text("• Số lượng nhóm đơn gộp: ${info.totalGroups} nhóm")
                    Text("• Số lượng ảnh đính kèm: ${info.totalPhotos} ảnh")
                    Text("• Tổng giá trị tất cả đơn: ${OrderCalculator.formatVnd(info.totalAllAmountVnd)}")
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "CẢNH BÁO: Thao tác khôi phục sẽ thay thế dữ liệu hiện tại trên máy bằng dữ liệu trong bản sao lưu này. Bạn có chắc chắn muốn tiếp tục?",
                        fontSize = 13.sp,
                        color = StatusCancelledRed,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = onConfirmRestore,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryYellow)
                ) {
                    Text("Đồng ý Khôi phục", color = TextPrimaryDark, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = onCancelRestore) {
                    Text("Hủy bỏ")
                }
            }
        )
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Sao lưu & Khôi phục dữ liệu (Offline ZIP)",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 18.sp,
            color = TextPrimaryDark
        )

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = PrimaryYellowContainer),
            border = BorderStroke(1.dp, PrimaryYellow),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = PrimaryYellowDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Trạng thái dữ liệu hiện tại trên thiết bị",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text("• Tổng số đơn đang lưu: $totalOrdersInDb đơn hàng")
                Text("• Tổng số nhóm đơn gộp: $totalGroupsInDb nhóm")
                Text(
                    text = "• Toàn bộ dữ liệu và hình ảnh được lưu bền vững trong bộ nhớ nội bộ của ứng dụng, không bị mất khi đóng ứng dụng hoặc khởi động lại điện thoại.",
                    fontSize = 12.sp,
                    color = TextSecondaryGray
                )
            }
        }

        // Khối 1: Xuất bản sao lưu
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "1. Xuất bản sao lưu dữ liệu & hình ảnh (.zip)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Đóng gói toàn bộ danh sách đơn hàng (mã đơn, giá tiền, ngày thống kê, trạng thái, ghi chú), nhóm đơn gộp và tất cả tệp ảnh đính kèm vào một tệp .zip duy nhất.",
                    fontSize = 13.sp,
                    color = TextSecondaryGray
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                        exportLauncher.launch("ThongKeDonHang_Backup_$stamp.zip")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryYellow),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null, tint = TextPrimaryDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Tạo tệp Sao lưu (.zip) ngay",
                        color = TextPrimaryDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }

        // Khối 2: Khôi phục từ bản sao lưu
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "2. Khôi phục dữ liệu từ bản sao lưu (.zip)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Khi cài lại ứng dụng hoặc chuyển sang điện thoại mới, chọn tệp .zip đã sao lưu. Hệ thống sẽ tự động kiểm tra tính hợp lệ và hiển thị thông tin để bạn xác nhận trước khi khôi phục.",
                    fontSize = 13.sp,
                    color = TextSecondaryGray
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = {
                        importLauncher.launch(arrayOf("application/zip", "application/octet-stream"))
                    },
                    border = BorderStroke(1.5.dp, PrimaryYellowDark),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null, tint = PrimaryYellowDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Chọn tệp Sao lưu (.zip) để Khôi phục",
                        color = TextPrimaryDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }

        // Hướng dẫn an toàn dữ liệu
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.Top,
                modifier = Modifier.padding(14.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = StatusSuccessGreen,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Cơ chế bảo vệ dữ liệu tự động",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "• Nếu tệp sao lưu bị hỏng, sai định dạng hoặc vi phạm quy tắc (như vượt quá 100 đơn/ngày hoặc quá 3 ảnh/đơn), hệ thống sẽ từ chối ngay và giữ nguyên dữ liệu hiện tại.
• Khi cập nhật phiên bản APK mới có cùng chữ ký (signing key), bạn chỉ cần cài đè trực tiếp mà không cần gỡ ứng dụng cũ để giữ nguyên toàn bộ dữ liệu.",
                        fontSize = 12.sp,
                        color = TextSecondaryGray
                    )
                }
            }
        }
    }
}
