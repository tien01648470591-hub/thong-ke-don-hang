package vn.thongkedonhang.app.domain.model

/**
 * Ba trạng thái đơn hàng theo yêu cầu Phần 6:
 * 1. Xanh lá — Giao thành công (DELIVERED_SUCCESS)
 * 2. Vàng — Chờ chuyển khoản (WAITING_TRANSFER)
 * 3. Đỏ — Hủy đơn (CANCELLED)
 */
enum class OrderStatus(
    val displayName: String,
    val shortLabel: String,
    val colorHex: Long,
    val badgeBgHex: Long
) {
    DELIVERED_SUCCESS(
        displayName = "Giao thành công",
        shortLabel = "Thành công",
        colorHex = 0xFF16A34A,
        badgeBgHex = 0xFFDCFCE7
    ),
    WAITING_TRANSFER(
        displayName = "Chờ chuyển khoản",
        shortLabel = "Chờ CK",
        colorHex = 0xFFD97706,
        badgeBgHex = 0xFFFEF9C3
    ),
    CANCELLED(
        displayName = "Hủy đơn",
        shortLabel = "Đã hủy",
        colorHex = 0xFFDC2626,
        badgeBgHex = 0xFFFEE2E2
    );

    companion object {
        fun fromName(value: String?): OrderStatus {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) }
                ?: WAITING_TRANSFER
        }
    }
}
