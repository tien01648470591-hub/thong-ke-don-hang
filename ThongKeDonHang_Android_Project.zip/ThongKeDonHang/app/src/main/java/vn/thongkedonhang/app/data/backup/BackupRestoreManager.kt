package vn.thongkedonhang.app.data.backup

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import vn.thongkedonhang.app.data.local.dao.OrderDao
import vn.thongkedonhang.app.data.local.entity.OrderEntity
import vn.thongkedonhang.app.data.local.entity.OrderGroupEntity
import vn.thongkedonhang.app.data.local.entity.OrderPhotoEntity
import vn.thongkedonhang.app.data.storage.PhotoStorageManager
import vn.thongkedonhang.app.domain.model.OrderConstants
import vn.thongkedonhang.app.domain.model.OrderStatus
import vn.thongkedonhang.app.domain.util.OrderCalculator
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Quản lý Sao lưu và Khôi phục dữ liệu hoàn chỉnh qua tệp ZIP (Phần 13):
 * - Đóng gói toàn bộ dữ liệu: đơn hàng (mã đơn, giá tiền, ngày, trạng thái, ghi chú, nhóm),
 *   nhóm đơn gộp và toàn bộ tệp hình ảnh đính kèm vào 1 tệp ZIP duy nhất.
 * - Kiểm tra tính hợp lệ nghiêm ngặt của bản sao lưu trước khi khôi phục (validateBackupFile):
 *   + Kiểm tra cấu trúc JSON, phiên bản schema.
 *   + Kiểm tra giới hạn tối đa 100 đơn/ngày cho từng ngày trong bản sao lưu.
 *   + Kiểm tra giới hạn tối đa 3 ảnh/đơn.
 *   + Kiểm tra tệp ảnh đính kèm thực sự tồn tại trong gói ZIP.
 * - Chỉ thay thế dữ liệu sau khi người dùng xác nhận.
 */
data class BackupPreviewInfo(
    val schemaVersion: Int,
    val createdAtMillis: Long,
    val totalOrders: Int,
    val totalGroups: Int,
    val totalPhotos: Int,
    val totalAllAmountVnd: Long
)

class BackupRestoreManager(
    private val context: Context,
    private val orderDao: OrderDao,
    private val photoStorageManager: PhotoStorageManager
) {

    companion object {
        const val MANIFEST_ENTRY_NAME = "backup_manifest.json"
        const val PHOTOS_ZIP_PREFIX = "photos/"
        const val CURRENT_SCHEMA_VERSION = 1
    }

    /**
     * Xuất toàn bộ dữ liệu + ảnh đính kèm ra luồng OutputStream (tệp ZIP).
     */
    suspend fun exportBackupToStream(outputStream: OutputStream): Result<BackupPreviewInfo> =
        withContext(Dispatchers.IO) {
            try {
                val groups = orderDao.getAllGroupsOnce()
                val orders = orderDao.getAllOrderEntitiesRaw()
                val photos = orderDao.getAllPhotoEntitiesRaw()
                val now = System.currentTimeMillis()

                val rootJson = JSONObject().apply {
                    put("app", "ThongKeDonHang")
                    put("schemaVersion", CURRENT_SCHEMA_VERSION)
                    put("exportedAtMillis", now)

                    val groupsArray = JSONArray()
                    for (g in groups) {
                        groupsArray.put(
                            JSONObject().apply {
                                put("groupId", g.groupId)
                                put("groupCode", g.groupCode)
                                put("groupName", g.groupName)
                                put("note", g.note)
                                put("createdDate", g.createdDate)
                                put("createdAtMillis", g.createdAtMillis)
                            }
                        )
                    }
                    put("groups", groupsArray)

                    val ordersArray = JSONArray()
                    for (o in orders) {
                        ordersArray.put(
                            JSONObject().apply {
                                put("id", o.id)
                                put("orderCode", o.orderCode)
                                put("codeSuffix4", o.codeSuffix4)
                                put("amountVnd", o.amountVnd)
                                put("status", o.status)
                                put("statDate", o.statDate)
                                put("createdAtMillis", o.createdAtMillis)
                                put("updatedAtMillis", o.updatedAtMillis)
                                put("groupId", o.groupId ?: JSONObject.NULL)
                                put("note", o.note)
                            }
                        )
                    }
                    put("orders", ordersArray)

                    val photosArray = JSONArray()
                    for (p in photos) {
                        photosArray.put(
                            JSONObject().apply {
                                put("photoId", p.photoId)
                                put("orderId", p.orderId)
                                put("relativePath", p.relativePath)
                                put("position", p.position)
                                put("createdAtMillis", p.createdAtMillis)
                            }
                        )
                    }
                    put("photos", photosArray)
                }

                ZipOutputStream(BufferedOutputStream(outputStream)).use { zos ->
                    // 1. Ghi backup_manifest.json
                    val manifestEntry = ZipEntry(MANIFEST_ENTRY_NAME)
                    zos.putNextEntry(manifestEntry)
                    val jsonBytes = rootJson.toString(2).toByteArray(Charsets.UTF_8)
                    zos.write(jsonBytes)
                    zos.closeEntry()

                    // 2. Ghi từng tệp ảnh đính kèm
                    for (photo in photos) {
                        val photoFile = photoStorageManager.resolvePhotoFile(photo.relativePath)
                        if (photoFile.exists() && photoFile.isFile) {
                            val entryName = "$PHOTOS_ZIP_PREFIX${photo.relativePath}"
                            zos.putNextEntry(ZipEntry(entryName))
                            FileInputStream(photoFile).use { fis ->
                                fis.copyTo(zos)
                            }
                            zos.closeEntry()
                        }
                    }
                    zos.finish()
                }

                val totalAmount = orders.sumOf { it.amountVnd.coerceAtLeast(0L) }
                Result.success(
                    BackupPreviewInfo(
                        schemaVersion = CURRENT_SCHEMA_VERSION,
                        createdAtMillis = now,
                        totalOrders = orders.size,
                        totalGroups = groups.size,
                        totalPhotos = photos.size,
                        totalAllAmountVnd = totalAmount
                    )
                )
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun exportBackupToUri(destUri: Uri): Result<BackupPreviewInfo> =
        withContext(Dispatchers.IO) {
            try {
                val out = context.contentResolver.openOutputStream(destUri)
                    ?: return@withContext Result.failure(IllegalArgumentException("Không thể mở tệp đích để lưu bản sao lưu."))
                out.use { stream ->
                    exportBackupToStream(stream)
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    /**
     * Đọc và kiểm tra tính hợp lệ của bản sao lưu trước khi cho phép người dùng xác nhận khôi phục.
     */
    suspend fun inspectAndValidateBackupUri(sourceUri: Uri): Result<BackupPreviewInfo> =
        withContext(Dispatchers.IO) {
            try {
                val input = context.contentResolver.openInputStream(sourceUri)
                    ?: return@withContext Result.failure(IllegalArgumentException("Không thể mở tệp sao lưu đã chọn."))
                input.use { stream ->
                    val parsed = parseAndValidateZipStream(stream, extractPhotosToDir = null)
                    parsed.map { it.previewInfo }
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    /**
     * Khôi phục toàn bộ dữ liệu và ảnh từ tệp ZIP sau khi người dùng đã xác nhận.
     * Nếu tệp không hợp lệ, dữ liệu hiện tại được giữ nguyên 100%.
     */
    suspend fun restoreFromBackupUri(sourceUri: Uri): Result<BackupPreviewInfo> =
        withContext(Dispatchers.IO) {
            val stagingDir = File(context.cacheDir, "backup_temp/restore_${System.currentTimeMillis()}").apply {
                if (exists()) deleteRecursively()
                mkdirs()
            }
            try {
                val input = context.contentResolver.openInputStream(sourceUri)
                    ?: return@withContext Result.failure(IllegalArgumentException("Không thể mở tệp sao lưu."))
                val parsedResult = input.use { stream ->
                    parseAndValidateZipStream(stream, extractPhotosToDir = stagingDir)
                }
                val parsed = parsedResult.getOrElse { err ->
                    stagingDir.deleteRecursively()
                    return@withContext Result.failure(err)
                }

                // 1. Cập nhật Database trong một @Transaction nguyên tử
                orderDao.replaceAllDataForRestore(
                    groups = parsed.groups,
                    orders = parsed.orders,
                    photos = parsed.photos
                )

                // 2. Cập nhật thư mục ảnh nội bộ
                val targetPhotosRoot = photoStorageManager.rootPhotosDir
                targetPhotosRoot.deleteRecursively()
                targetPhotosRoot.mkdirs()
                if (stagingDir.exists()) {
                    stagingDir.copyRecursively(targetPhotosRoot, overwrite = true)
                }
                stagingDir.deleteRecursively()

                Result.success(parsed.previewInfo)
            } catch (e: Exception) {
                stagingDir.deleteRecursively()
                Result.failure(e)
            }
        }

    private data class ValidatedBackupPayload(
        val previewInfo: BackupPreviewInfo,
        val groups: List<OrderGroupEntity>,
        val orders: List<OrderEntity>,
        val photos: List<OrderPhotoEntity>
    )

    private fun parseAndValidateZipStream(
        inputStream: InputStream,
        extractPhotosToDir: File?
    ): Result<ValidatedBackupPayload> {
        var manifestJsonStr: String? = null
        val extractedPhotoPaths = mutableSetOf<String>()

        ZipInputStream(BufferedInputStream(inputStream)).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val name = entry.name
                if (!entry.isDirectory) {
                    if (name == MANIFEST_ENTRY_NAME) {
                        val baos = ByteArrayOutputStream()
                        zis.copyTo(baos)
                        manifestJsonStr = baos.toString(Charsets.UTF_8.name())
                    } else if (name.startsWith(PHOTOS_ZIP_PREFIX)) {
                        val relPath = name.removePrefix(PHOTOS_ZIP_PREFIX)
                        if (relPath.isNotBlank() && !relPath.contains("..")) {
                            extractedPhotoPaths.add(relPath)
                            if (extractPhotosToDir != null) {
                                val outFile = File(extractPhotosToDir, relPath)
                                outFile.parentFile?.mkdirs()
                                FileOutputStream(outFile).use { fos ->
                                    zis.copyTo(fos)
                                }
                            }
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        val jsonText = manifestJsonStr
            ?: return Result.failure(IllegalArgumentException("Tệp sao lưu không hợp lệ: Thiếu tệp $MANIFEST_ENTRY_NAME."))

        val root = try {
            JSONObject(jsonText)
        } catch (e: Exception) {
            return Result.failure(IllegalArgumentException("Cấu trúc JSON trong bản sao lưu bị hỏng."))
        }

        if (root.optString("app") != "ThongKeDonHang") {
            return Result.failure(IllegalArgumentException("Tệp sao lưu không thuộc ứng dụng Thống kê đơn hàng."))
        }

        val schemaVersion = root.optInt("schemaVersion", -1)
        if (schemaVersion < 1 || schemaVersion > CURRENT_SCHEMA_VERSION) {
            return Result.failure(IllegalArgumentException("Phiên bản bản sao lưu không tương thích ($schemaVersion)."))
        }

        val exportedAt = root.optLong("exportedAtMillis", System.currentTimeMillis())

        val groupsArray = root.optJSONArray("groups") ?: JSONArray()
        val groups = mutableListOf<OrderGroupEntity>()
        val groupIds = mutableSetOf<String>()
        for (i in 0 until groupsArray.length()) {
            val gObj = groupsArray.getJSONObject(i)
            val gId = gObj.optString("groupId").trim()
            val gCode = gObj.optString("groupCode").trim()
            val gName = gObj.optString("groupName").trim()
            if (gId.isEmpty() || gName.isEmpty()) {
                return Result.failure(IllegalArgumentException("Dữ liệu nhóm đơn gộp tại vị trí $i không hợp lệ."))
            }
            groupIds.add(gId)
            groups.add(
                OrderGroupEntity(
                    groupId = gId,
                    groupCode = gCode.ifEmpty { "GRP-${i + 1}" },
                    groupName = gName,
                    note = gObj.optString("note", ""),
                    createdDate = gObj.optString("createdDate", "2026-01-01"),
                    createdAtMillis = gObj.optLong("createdAtMillis", exportedAt)
                )
            )
        }

        val ordersArray = root.optJSONArray("orders") ?: JSONArray()
        val orders = mutableListOf<OrderEntity>()
        val orderIds = mutableSetOf<String>()
        val countByDate = mutableMapOf<String, Int>()

        for (i in 0 until ordersArray.length()) {
            val oObj = ordersArray.getJSONObject(i)
            val id = oObj.optString("id").trim()
            val code = oObj.optString("orderCode").trim()
            val amount = oObj.optLong("amountVnd", -1L)
            val statDate = oObj.optString("statDate").trim()
            val statusStr = oObj.optString("status").trim()
            if (id.isEmpty() || code.isEmpty() || statDate.isEmpty() || amount < 0L) {
                return Result.failure(IllegalArgumentException("Dữ liệu đơn hàng tại vị trí $i không hợp lệ."))
            }
            val newDateCount = (countByDate[statDate] ?: 0) + 1
            if (newDateCount > OrderConstants.MAX_ORDERS_PER_DAY) {
                return Result.failure(
                    IllegalArgumentException("Bản sao lưu vi phạm giới hạn 100 đơn/ngày tại ngày $statDate.")
                )
            }
            countByDate[statDate] = newDateCount
            orderIds.add(id)

            val rawGroupId = if (oObj.isNull("groupId")) null else oObj.optString("groupId").takeIf { it.isNotBlank() }
            val validGroupId = if (rawGroupId != null && groupIds.contains(rawGroupId)) rawGroupId else null

            orders.add(
                OrderEntity(
                    id = id,
                    orderCode = code,
                    codeSuffix4 = OrderCalculator.extractSuffix4(code),
                    amountVnd = amount,
                    status = OrderStatus.fromName(statusStr).name,
                    statDate = statDate,
                    createdAtMillis = oObj.optLong("createdAtMillis", exportedAt),
                    updatedAtMillis = oObj.optLong("updatedAtMillis", exportedAt),
                    groupId = validGroupId,
                    note = oObj.optString("note", "")
                )
            )
        }

        val photosArray = root.optJSONArray("photos") ?: JSONArray()
        val photos = mutableListOf<OrderPhotoEntity>()
        val photoCountByOrder = mutableMapOf<String, Int>()
        for (i in 0 until photosArray.length()) {
            val pObj = photosArray.getJSONObject(i)
            val pId = pObj.optString("photoId").trim()
            val oId = pObj.optString("orderId").trim()
            val relPath = pObj.optString("relativePath").trim()
            if (pId.isEmpty() || oId.isEmpty() || !orderIds.contains(oId) || relPath.isEmpty()) {
                return Result.failure(IllegalArgumentException("Dữ liệu ảnh đính kèm tại vị trí $i không hợp lệ."))
            }
            val pCount = (photoCountByOrder[oId] ?: 0) + 1
            if (pCount > OrderConstants.MAX_PHOTOS_PER_ORDER) {
                return Result.failure(IllegalArgumentException("Đơn hàng $oId trong bản sao lưu vượt quá 3 ảnh đính kèm."))
            }
            photoCountByOrder[oId] = pCount
            photos.add(
                OrderPhotoEntity(
                    photoId = pId,
                    orderId = oId,
                    relativePath = relPath,
                    position = pObj.optInt("position", pCount - 1),
                    createdAtMillis = pObj.optLong("createdAtMillis", exportedAt)
                )
            )
        }

        val preview = BackupPreviewInfo(
            schemaVersion = schemaVersion,
            createdAtMillis = exportedAt,
            totalOrders = orders.size,
            totalGroups = groups.size,
            totalPhotos = photos.size,
            totalAllAmountVnd = orders.sumOf { it.amountVnd }
        )

        return Result.success(
            ValidatedBackupPayload(
                previewInfo = preview,
                groups = groups,
                orders = orders,
                photos = photos
            )
        )
    }
}
