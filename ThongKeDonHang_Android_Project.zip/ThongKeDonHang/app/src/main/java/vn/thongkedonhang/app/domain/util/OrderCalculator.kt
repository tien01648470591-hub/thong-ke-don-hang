package vn.thongkedonhang.app.domain.util

import vn.thongkedonhang.app.domain.model.OrderConstants
import vn.thongkedonhang.app.domain.model.OrderItem
import vn.thongkedonhang.app.domain.model.OrderStatus
import vn.thongkedonhang.app.domain.model.OrderSummaryStats
import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

/**
 * Bộ xử lý tính toán thống kê, định dạng tiền tệ VNĐ, rút trích 4 số cuối và kiểm tra khoảng ngày.
 * Đảm bảo 100% tính nhất quán giữa Tổng tiền ngày, Tổng tiền nhóm và Tổng tiền từng trạng thái.
 */
object OrderCalculator {

    private val isoFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    private val vnDateFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    /**
     * Tính toán thống kê từ danh sách đơn hàng theo đúng Quy tắc Phần 7:
     * - totalAllAmountVnd = tổng giá tiền của TẤT CẢ các đơn (Giao thành công + Chờ chuyển khoản + Hủy đơn).
     * - Đơn hủy giữ nguyên giá tiền và KHÔNG bị trừ khỏi totalAllAmountVnd.
     * - Đơn 0 đồng vẫn được tính vào số lượng đơn (totalOrders).
     */
    fun calculateStats(
        orders: List<OrderItem>,
        label: String = ""
    ): OrderSummaryStats {
        var totalAllAmount = 0L
        var deliveredCount = 0
        var deliveredAmount = 0L
        var waitingCount = 0
        var waitingAmount = 0L
        var cancelledCount = 0
        var cancelledAmount = 0L

        for (order in orders) {
            val safeAmount = order.amountVnd.coerceAtLeast(0L)
            totalAllAmount += safeAmount
            when (order.status) {
                OrderStatus.DELIVERED_SUCCESS -> {
                    deliveredCount++
                    deliveredAmount += safeAmount
                }
                OrderStatus.WAITING_TRANSFER -> {
                    waitingCount++
                    waitingAmount += safeAmount
                }
                OrderStatus.CANCELLED -> {
                    cancelledCount++
                    cancelledAmount += safeAmount
                }
            }
        }

        val totalOrders = orders.size
        val remaining = (OrderConstants.MAX_ORDERS_PER_DAY - totalOrders).coerceAtLeast(0)

        return OrderSummaryStats(
            dateOrRangeLabel = label,
            totalOrders = totalOrders,
            totalAllAmountVnd = totalAllAmount,
            deliveredCount = deliveredCount,
            deliveredAmountVnd = deliveredAmount,
            waitingCount = waitingCount,
            waitingAmountVnd = waitingAmount,
            cancelledCount = cancelledCount,
            cancelledAmountVnd = cancelledAmount,
            dailyLimit = OrderConstants.MAX_ORDERS_PER_DAY,
            remainingDailyQuota = remaining
        )
    }

    /**
     * Định dạng tiền tệ đồng Việt Nam dễ đọc, ví dụ: 125.000 ₫ hoặc 0 ₫ (Phần 4).
     */
    fun formatVnd(amount: Long): String {
        val safeAmount = amount.coerceAtLeast(0L)
        val formatter = NumberFormat.getIntegerInstance(Locale("vi", "VN"))
        return "${formatter.format(safeAmount)} ₫"
    }

    /**
     * Chuyển chuỗi nhập liệu thành số nguyên không âm (mặc định 0 đồng nếu trống) (Phần 4).
     */
    fun parseAmountVnd(input: String?): Long {
        if (input.isNullOrBlank()) return 0L
        val digitsOnly = input.filter { it.isDigit() }
        if (digitsOnly.isEmpty()) return 0L
        return digitsOnly.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
    }

    /**
     * Trích xuất 4 ký tự/số cuối của mã đơn để phục vụ chỉ mục tìm kiếm nhanh (Phần 9).
     */
    fun extractSuffix4(orderCode: String): String {
        val cleaned = orderCode.trim().uppercase(Locale.ROOT)
        return if (cleaned.length <= 4) cleaned else cleaned.takeLast(4)
    }

    /**
     * Kiểm tra mã đơn có khớp với truy vấn tìm kiếm 4 số cuối (hoặc phần đuôi mã) hay không (Phần 9).
     * Trả về tất cả các đơn có phần cuối khớp với chuỗi tìm kiếm.
     */
    fun matchesSuffixQuery(orderCode: String, rawQuery: String): Boolean {
        val query = rawQuery.trim()
        if (query.isEmpty()) return true
        val normalizedCode = orderCode.trim()
        return normalizedCode.endsWith(query, ignoreCase = true)
    }

    /**
     * Kiểm tra khoảng ngày thống kê tối đa 1 tháng (tối đa 31 ngày) theo Phần 10.
     */
    fun validateDateRangeMaxOneMonth(startDateIso: String, endDateIso: String): Result<Long> {
        return try {
            val start = LocalDate.parse(startDateIso, isoFormatter)
            val end = LocalDate.parse(endDateIso, isoFormatter)
            if (end.isBefore(start)) {
                Result.failure(IllegalArgumentException("Ngày kết thúc không được nhỏ hơn ngày bắt đầu."))
            } else {
                val daysInclusive = ChronoUnit.DAYS.between(start, end) + 1
                if (daysInclusive > OrderConstants.MAX_REPORT_DAYS) {
                    Result.failure(
                        IllegalArgumentException(
                            "Khoảng thời gian thống kê tối đa là 1 tháng (${OrderConstants.MAX_REPORT_DAYS} ngày). Khoảng đang chọn là $daysInclusive ngày."
                        )
                    )
                } else {
                    Result.success(daysInclusive)
                }
            }
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("Định dạng ngày không hợp lệ (cần yyyy-MM-dd)."))
        }
    }

    fun formatIsoToVnDate(isoDate: String): String {
        return try {
            LocalDate.parse(isoDate, isoFormatter).format(vnDateFormatter)
        } catch (e: Exception) {
            isoDate
        }
    }
}
