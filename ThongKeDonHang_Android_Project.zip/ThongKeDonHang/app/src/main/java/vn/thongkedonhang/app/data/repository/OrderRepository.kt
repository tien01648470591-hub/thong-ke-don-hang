package vn.thongkedonhang.app.data.repository

import android.net.Uri
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import vn.thongkedonhang.app.data.backup.BackupPreviewInfo
import vn.thongkedonhang.app.data.backup.BackupRestoreManager
import vn.thongkedonhang.app.data.local.dao.DateOrderCount
import vn.thongkedonhang.app.data.local.dao.InsertOrderDbResult
import vn.thongkedonhang.app.data.local.dao.OrderDao
import vn.thongkedonhang.app.data.local.entity.OrderEntity
import vn.thongkedonhang.app.data.local.entity.OrderGroupEntity
import vn.thongkedonhang.app.data.local.entity.OrderPhotoEntity
import vn.thongkedonhang.app.data.storage.PhotoStorageManager
import vn.thongkedonhang.app.domain.model.DomainResult
import vn.thongkedonhang.app.domain.model.OrderConstants
import vn.thongkedonhang.app.domain.model.OrderGroupSummary
import vn.thongkedonhang.app.domain.model.OrderItem
import vn.thongkedonhang.app.domain.model.OrderStatus
import vn.thongkedonhang.app.domain.util.OrderCalculator
import java.io.File
import java.util.UUID

/**
 * Tầng Repository trung tâm kết nối Room Database, PhotoStorageManager và BackupRestoreManager.
 * Đảm bảo mọi ràng buộc nghiệp vụ (Giới hạn 100 đơn/ngày, Tối đa 3 ảnh/đơn, Cảnh báo trùng mã trong ngày,
 * Quy tắc tính tổng tiền không trừ đơn hủy, Đơn gộp, Tìm kiếm 4 số cuối) được thực thi nhất quán.
 */
class OrderRepository(
    private val orderDao: OrderDao,
    val photoStorageManager: PhotoStorageManager,
    val backupRestoreManager: BackupRestoreManager
) {

    // --- QUAN SÁT DỮ LIỆU THỜI GIAN THỰC (FLOW) ---

    fun observeOrdersByDate(statDate: String): Flow<List<OrderItem>> {
        return orderDao.observeOrdersByDate(statDate).map { list ->
            list.map { it.toDomainModel() }
        }
    }

    fun observeOrdersInRange(startDate: String, endDate: String): Flow<List<OrderItem>> {
        return orderDao.observeOrdersInRange(startDate, endDate).map { list ->
            list.map { it.toDomainModel() }
        }
    }

    fun observeAllOrders(): Flow<List<OrderItem>> {
        return orderDao.observeAllOrders().map { list ->
            list.map { it.toDomainModel() }
        }
    }

    fun observeOrderById(orderId: String): Flow<OrderItem?> {
        return orderDao.observeOrderById(orderId).map { it?.toDomainModel() }
    }

    fun observeOrderCountPerDate(): Flow<Map<String, Int>> {
        return orderDao.observeOrderCountPerDate().map { list ->
            list.associate { it.stat_date to it.cnt }
        }
    }

    fun observeAllGroupSummaries(): Flow<List<OrderGroupSummary>> {
        return combine(
            orderDao.observeAllGroups(),
            orderDao.observeAllOrders()
        ) { groups, allOrdersRelations ->
            val allOrders = allOrdersRelations.map { it.toDomainModel() }
            val ordersByGroup = allOrders.groupBy { it.groupId }
            groups.map { groupEntity ->
                val memberOrders = ordersByGroup[groupEntity.groupId].orEmpty()
                OrderGroupSummary(
                    groupId = groupEntity.groupId,
                    groupCode = groupEntity.groupCode,
                    groupName = groupEntity.groupName,
                    note = groupEntity.note,
                    createdDate = groupEntity.createdDate,
                    createdAtMillis = groupEntity.createdAtMillis,
                    orders = memberOrders,
                    stats = OrderCalculator.calculateStats(memberOrders, groupEntity.groupName)
                )
            }
        }
    }

    // --- TẠO ĐƠN HÀNG MỚI (QUÉT QR/BARCODE HOẶC NHẬP TAY) ---

    suspend fun checkDuplicateOrderInSameDay(
        orderCode: String,
        statDate: String
    ): OrderItem? {
        val cleaned = orderCode.trim()
        if (cleaned.isEmpty()) return null
        return orderDao.findByCodeAndDate(cleaned, statDate)?.toDomainModel()
    }

    suspend fun createOrder(
        orderCode: String,
        amountVnd: Long,
        status: OrderStatus,
        statDate: String,
        groupId: String? = null,
        note: String = "",
        photoUris: List<Uri> = emptyList()
    ): DomainResult<OrderItem> {
        val cleanedCode = orderCode.trim()
        if (cleanedCode.isEmpty()) {
            return DomainResult.ValidationError("Vui lòng nhập hoặc quét mã đơn hàng.")
        }
        if (amountVnd < 0L) {
            return DomainResult.ValidationError("Giá tiền không được là số âm.")
        }
        if (photoUris.size > OrderConstants.MAX_PHOTOS_PER_ORDER) {
            return DomainResult.PhotoLimitExceeded("Mỗi đơn hàng chỉ được đính kèm tối đa 3 ảnh.")
        }

        // 1. Kiểm tra trùng mã đơn trong cùng ngày (Phần 3)
        val existing = orderDao.findByCodeAndDate(cleanedCode, statDate)
        if (existing != null) {
            return DomainResult.DuplicateOrderSameDay(
                existingOrder = existing.toDomainModel(),
                message = "Mã đơn "$cleanedCode" đã tồn tại trong ngày ${OrderCalculator.formatIsoToVnDate(statDate)}."
            )
        }

        // 2. Kiểm tra giới hạn 100 đơn/ngày trước khi sao chép ảnh (Phần 10)
        val currentDailyCount = orderDao.countOrdersByDate(statDate)
        if (currentDailyCount >= OrderConstants.MAX_ORDERS_PER_DAY) {
            return DomainResult.DailyLimitExceeded(
                statDate = statDate,
                message = "Ngày này đã đạt giới hạn 100 đơn"
            )
        }

        val now = System.currentTimeMillis()
        val orderId = UUID.randomUUID().toString()
        val suffix4 = OrderCalculator.extractSuffix4(cleanedCode)

        // 3. Sao chép tối đa 3 ảnh vào bộ nhớ nội bộ của đơn
        val photoEntities = mutableListOf<OrderPhotoEntity>()
        for ((index, uri) in photoUris.withIndex()) {
            val photoId = UUID.randomUUID().toString()
            val copyResult = photoStorageManager.copyUriToOrderInternalStorage(orderId, photoId, uri)
            val relPath = copyResult.getOrElse {
                photoStorageManager.deleteAllPhotosForOrder(orderId)
                return DomainResult.ValidationError("Lỗi lưu ảnh đính kèm: ${it.message}")
            }
            photoEntities.add(
                OrderPhotoEntity(
                    photoId = photoId,
                    orderId = orderId,
                    relativePath = relPath,
                    position = index,
                    createdAtMillis = now + index
                )
            )
        }

        val orderEntity = OrderEntity(
            id = orderId,
            orderCode = cleanedCode,
            codeSuffix4 = suffix4,
            amountVnd = amountVnd,
            status = status.name,
            statDate = statDate,
            createdAtMillis = now,
            updatedAtMillis = now,
            groupId = groupId,
            note = note.trim()
        )

        // 4. Thực thi @Transaction kiểm tra lại giới hạn 100 đơn/ngày ở tầng DB để chống race condition
        return when (orderDao.insertOrderWithDailyLimitCheck(orderEntity, photoEntities)) {
            InsertOrderDbResult.SUCCESS -> {
                val saved = orderDao.getOrderByIdOnce(orderId)?.toDomainModel()
                    ?: return DomainResult.ValidationError("Không thể đọc lại đơn hàng vừa tạo.")
                DomainResult.Success(saved)
            }
            InsertOrderDbResult.DAILY_LIMIT_REACHED -> {
                photoStorageManager.deleteAllPhotosForOrder(orderId)
                DomainResult.DailyLimitExceeded(
                    statDate = statDate,
                    message = "Ngày này đã đạt giới hạn 100 đơn"
                )
            }
            InsertOrderDbResult.DUPLICATE_IN_SAME_DAY -> {
                photoStorageManager.deleteAllPhotosForOrder(orderId)
                val dup = orderDao.findByCodeAndDate(cleanedCode, statDate)?.toDomainModel()
                if (dup != null) {
                    DomainResult.DuplicateOrderSameDay(
                        existingOrder = dup,
                        message = "Mã đơn "$cleanedCode" đã tồn tại trong ngày ${OrderCalculator.formatIsoToVnDate(statDate)}."
                    )
                } else {
                    DomainResult.ValidationError("Mã đơn đã tồn tại trong ngày.")
                }
            }
            InsertOrderDbResult.PHOTO_LIMIT_EXCEEDED -> {
                photoStorageManager.deleteAllPhotosForOrder(orderId)
                DomainResult.PhotoLimitExceeded("Mỗi đơn hàng chỉ được đính kèm tối đa 3 ảnh.")
            }
        }
    }

    // --- CẬP NHẬT TRẠNG THÁI, GIÁ TIỀN, THÔNG TIN ĐƠN (PHẦN 4, 6, 7) ---

    /**
     * Đổi trạng thái đơn hàng:
     * - Lưu ngay vào cơ sở dữ liệu.
     * - Giữ nguyên mã đơn, ảnh và giá tiền (tuyệt đối không xóa giá tiền khi hủy đơn).
     * - Không tạo thêm bản ghi mới.
     */
    suspend fun updateOrderStatus(orderId: String, newStatus: OrderStatus): DomainResult<Unit> {
        orderDao.updateOrderStatusOnly(orderId, newStatus.name, System.currentTimeMillis())
        return DomainResult.Success(Unit)
    }

    /**
     * Sửa giá tiền của một đơn hàng:
     * - Cập nhật ngay lập tức trong cơ sở dữ liệu và tự động tính lại các tổng tiền qua Flow.
     */
    suspend fun updateOrderAmount(orderId: String, newAmountVnd: Long): DomainResult<Unit> {
        if (newAmountVnd < 0L) {
            return DomainResult.ValidationError("Giá tiền phải là số nguyên không âm.")
        }
        orderDao.updateOrderAmountOnly(orderId, newAmountVnd, System.currentTimeMillis())
        return DomainResult.Success(Unit)
    }

    /**
     * Cập nhật đầy đủ thông tin đơn hàng (mã đơn, giá tiền, trạng thái, nhóm, ghi chú).
     * Giữ nguyên ngày thống kê gốc (statDate) của đơn.
     */
    suspend fun updateOrderDetails(
        orderId: String,
        newOrderCode: String,
        newAmountVnd: Long,
        newStatus: OrderStatus,
        newGroupId: String?,
        newNote: String
    ): DomainResult<OrderItem> {
        val current = orderDao.getOrderByIdOnce(orderId)
            ?: return DomainResult.ValidationError("Không tìm thấy đơn hàng cần sửa.")
        val cleanedCode = newOrderCode.trim()
        if (cleanedCode.isEmpty()) {
            return DomainResult.ValidationError("Mã đơn hàng không được để trống.")
        }
        if (newAmountVnd < 0L) {
            return DomainResult.ValidationError("Giá tiền không hợp lệ.")
        }

        // Kiểm tra nếu đổi sang mã khác đã tồn tại trong cùng ngày
        if (!cleanedCode.equals(current.order.orderCode, ignoreCase = true)) {
            val conflict = orderDao.findByCodeAndDate(cleanedCode, current.order.statDate)
            if (conflict != null && conflict.order.id != orderId) {
                return DomainResult.DuplicateOrderSameDay(
                    existingOrder = conflict.toDomainModel(),
                    message = "Mã đơn "$cleanedCode" đã tồn tại trong ngày này."
                )
            }
        }

        val updatedEntity = current.order.copy(
            orderCode = cleanedCode,
            codeSuffix4 = OrderCalculator.extractSuffix4(cleanedCode),
            amountVnd = newAmountVnd,
            status = newStatus.name,
            groupId = newGroupId,
            note = newNote.trim(),
            updatedAtMillis = System.currentTimeMillis()
        )
        orderDao.updateOrder(updatedEntity)
        val refreshed = orderDao.getOrderByIdOnce(orderId)?.toDomainModel()
            ?: return DomainResult.ValidationError("Không thể tải lại đơn sau khi sửa.")
        return DomainResult.Success(refreshed)
    }

    // --- QUẢN LÝ ẢNH ĐÍNH KÈM TRONG CHI TIẾT ĐƠN (PHẦN 5) ---

    suspend fun addPhotoToExistingOrder(orderId: String, sourceUri: Uri): DomainResult<Unit> {
        val existingPhotos = orderDao.getPhotosForOrder(orderId)
        if (existingPhotos.size >= OrderConstants.MAX_PHOTOS_PER_ORDER) {
            return DomainResult.PhotoLimitExceeded(
                "Đã đạt giới hạn 3 ảnh cho đơn hàng này. Không thể thêm ảnh thứ 4."
            )
        }
        val nextPosition = (existingPhotos.maxOfOrNull { it.position } ?: -1) + 1
        val photoId = UUID.randomUUID().toString()
        val copyResult = photoStorageManager.copyUriToOrderInternalStorage(orderId, photoId, sourceUri)
        val relPath = copyResult.getOrElse {
            return DomainResult.ValidationError("Không thể lưu ảnh: ${it.message}")
        }
        orderDao.insertPhoto(
            OrderPhotoEntity(
                photoId = photoId,
                orderId = orderId,
                relativePath = relPath,
                position = nextPosition,
                createdAtMillis = System.currentTimeMillis()
            )
        )
        return DomainResult.Success(Unit)
    }

    suspend fun replaceOrderPhoto(
        orderId: String,
        oldPhotoId: String,
        newSourceUri: Uri
    ): DomainResult<Unit> {
        val existingPhotos = orderDao.getPhotosForOrder(orderId)
        val target = existingPhotos.firstOrNull { it.photoId == oldPhotoId }
            ?: return DomainResult.ValidationError("Không tìm thấy ảnh cần thay thế.")

        val newPhotoId = UUID.randomUUID().toString()
        val copyResult = photoStorageManager.copyUriToOrderInternalStorage(orderId, newPhotoId, newSourceUri)
        val newRelPath = copyResult.getOrElse {
            return DomainResult.ValidationError("Không thể lưu ảnh thay thế: ${it.message}")
        }

        // Xóa tệp ảnh cũ và bản ghi cũ, lưu bản ghi mới giữ nguyên vị trí position
        photoStorageManager.deleteSinglePhotoFile(target.relativePath)
        orderDao.deletePhotoById(oldPhotoId)
        orderDao.insertPhoto(
            OrderPhotoEntity(
                photoId = newPhotoId,
                orderId = orderId,
                relativePath = newRelPath,
                position = target.position,
                createdAtMillis = System.currentTimeMillis()
            )
        )
        return DomainResult.Success(Unit)
    }

    suspend fun deleteSingleOrderPhoto(orderId: String, photoId: String): DomainResult<Unit> {
        val existingPhotos = orderDao.getPhotosForOrder(orderId)
        val target = existingPhotos.firstOrNull { it.photoId == photoId }
            ?: return DomainResult.ValidationError("Không tìm thấy ảnh cần xóa.")
        photoStorageManager.deleteSinglePhotoFile(target.relativePath)
        orderDao.deletePhotoById(photoId)
        return DomainResult.Success(Unit)
    }

    /**
     * Xóa đơn hàng và dọn dẹp an toàn thư mục ảnh của riêng đơn đó (Phần 5 & Phần 12).
     */
    suspend fun deleteOrder(orderId: String): DomainResult<Unit> {
        photoStorageManager.deleteAllPhotosForOrder(orderId)
        orderDao.deleteOrderById(orderId)
        return DomainResult.Success(Unit)
    }

    // --- TÌM KIẾM BẰNG 4 SỐ CUỐI (PHẦN 9) ---

    suspend fun searchOrdersByLast4Digits(
        suffixQuery: String,
        statDate: String?,
        startDate: String?,
        endDate: String?
    ): List<OrderItem> {
        val cleaned = suffixQuery.trim()
        val relations = when {
            statDate != null -> orderDao.searchBySuffixInDate(statDate, cleaned)
            startDate != null && endDate != null -> orderDao.searchBySuffixInRange(startDate, endDate, cleaned)
            else -> orderDao.searchBySuffixInRange("1970-01-01", "2099-12-31", cleaned)
        }
        return relations
            .map { it.toDomainModel() }
            .filter { OrderCalculator.matchesSuffixQuery(it.orderCode, cleaned) }
    }

    // --- QUẢN LÝ NHÓM ĐƠN GỘP (PHẦN 8) ---

    suspend fun createOrderGroup(
        groupName: String,
        note: String,
        createdDate: String
    ): DomainResult<OrderGroupEntity> {
        val cleanedName = groupName.trim()
        if (cleanedName.isEmpty()) {
            return DomainResult.ValidationError("Vui lòng nhập tên nhóm đơn gộp (ví dụ: Khách A, Nhóm 01).")
        }
        val existingGroups = orderDao.getAllGroupsOnce()
        val nextIndex = existingGroups.size + 1
        val groupId = UUID.randomUUID().toString()
        val groupCode = "GRP-${createdDate.replace("-", "")}-${nextIndex.toString().padStart(3, '0')}-${groupId.take(4).uppercase()}"
        val entity = OrderGroupEntity(
            groupId = groupId,
            groupCode = groupCode,
            groupName = cleanedName,
            note = note.trim(),
            createdDate = createdDate,
            createdAtMillis = System.currentTimeMillis()
        )
        orderDao.insertGroup(entity)
        return DomainResult.Success(entity)
    }

    suspend fun renameOrderGroup(
        groupId: String,
        newName: String,
        newNote: String
    ): DomainResult<Unit> {
        val cleaned = newName.trim()
        if (cleaned.isEmpty()) {
            return DomainResult.ValidationError("Tên nhóm không được để trống.")
        }
        orderDao.updateGroupNameAndNote(groupId, cleaned, newNote.trim())
        return DomainResult.Success(Unit)
    }

    suspend fun assignOrderToGroup(orderId: String, groupId: String?): DomainResult<Unit> {
        orderDao.assignOrderToGroup(orderId, groupId, System.currentTimeMillis())
        return DomainResult.Success(Unit)
    }

    /**
     * Xóa nhóm đơn gộp mà KHÔNG xóa các đơn hàng bên trong (Phần 8).
     */
    suspend fun deleteGroupKeepingOrders(groupId: String): DomainResult<Unit> {
        orderDao.deleteGroupKeepingOrders(groupId, System.currentTimeMillis())
        return DomainResult.Success(Unit)
    }

    // --- SAO LƯU & KHÔI PHỤC (PHẦN 13) ---

    suspend fun exportBackup(destUri: Uri): Result<BackupPreviewInfo> {
        return backupRestoreManager.exportBackupToUri(destUri)
    }

    suspend fun validateBackup(sourceUri: Uri): Result<BackupPreviewInfo> {
        return backupRestoreManager.inspectAndValidateBackupUri(sourceUri)
    }

    suspend fun restoreBackup(sourceUri: Uri): Result<BackupPreviewInfo> {
        return backupRestoreManager.restoreFromBackupUri(sourceUri)
    }

    fun resolvePhotoFile(relativePath: String): File {
        return photoStorageManager.resolvePhotoFile(relativePath)
    }
}
