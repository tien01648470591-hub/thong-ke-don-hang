package vn.thongkedonhang.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import vn.thongkedonhang.app.domain.model.OrderStatus
import vn.thongkedonhang.app.domain.model.OrderSummaryStats
import vn.thongkedonhang.app.domain.util.OrderCalculator
import vn.thongkedonhang.app.ui.components.DateNavigatorBar
import vn.thongkedonhang.app.ui.theme.CardGrayBorder
import vn.thongkedonhang.app.ui.theme.PrimaryYellow
import vn.thongkedonhang.app.ui.theme.PrimaryYellowContainer
import vn.thongkedonhang.app.ui.theme.PrimaryYellowDark
import vn.thongkedonhang.app.ui.theme.SoftCreamSurface
import vn.thongkedonhang.app.ui.theme.StatusCancelledBg
import vn.thongkedonhang.app.ui.theme.StatusCancelledRed
import vn.thongkedonhang.app.ui.theme.StatusSuccessBg
import vn.thongkedonhang.app.ui.theme.StatusSuccessGreen
import vn.thongkedonhang.app.ui.theme.StatusWaitingBg
import vn.thongkedonhang.app.ui.theme.StatusWaitingYellow
import vn.thongkedonhang.app.ui.theme.TextPrimaryDark
import vn.thongkedonhang.app.ui.theme.TextSecondaryGray

@Composable
fun OverviewScreen(
    selectedDateIso: String,
    dailyStats: OrderSummaryStats,
    rangeStats: OrderSummaryStats,
    onPreviousDay: () -> Unit,
    onNextDay: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenOrderListWithFilter: (OrderStatus?) -> Unit,
    onNavigateToAddOrder: (scanMode: Boolean) -> Unit,
    onNavigateToGroups: () -> Unit,
    onNavigateToReport: () -> Unit,
    onNavigateToBackup: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Thanh điều hướng ngày đang xem & hạn mức 100 đơn/ngày
        DateNavigatorBar(
            selectedDateIso = selectedDateIso,
            orderCountInDay = dailyStats.totalOrders,
            onPreviousDay = onPreviousDay,
            onNextDay = onNextDay,
            onOpenCalendarScreen = onOpenCalendar
        )

        // 2. Hai nút thao tác nhanh lớn (Quét mã QR/Barcode & Nhập đơn thủ công)
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = { onNavigateToAddOrder(true) },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryYellow),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp)
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = TextPrimaryDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Quét mã thêm đơn",
                    color = TextPrimaryDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            OutlinedButton(
                onClick = { onNavigateToAddOrder(false) },
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.5.dp, PrimaryYellowDark),
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp)
            ) {
                Icon(Icons.Default.AddCircle, contentDescription = null, tint = PrimaryYellowDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Nhập mã thủ công",
                    color = TextPrimaryDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }

        // 3. Thẻ Tổng số đơn & Tổng giá trị tất cả đơn trong ngày (Bấm mở toàn bộ danh sách đơn)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PrimaryYellowContainer),
            border = BorderStroke(1.5.dp, PrimaryYellow),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onOpenOrderListWithFilter(null) }
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "TỔNG QUAN NGÀY ${OrderCalculator.formatIsoToVnDate(selectedDateIso)}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryYellowDark
                    )
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "Còn lại: ${dailyStats.remainingDailyQuota}/100 đơn",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (dailyStats.remainingDailyQuota == 0) StatusCancelledRed else TextPrimaryDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "Tổng số đơn trong ngày",
                            fontSize = 13.sp,
                            color = TextSecondaryGray
                        )
                        Text(
                            text = "${dailyStats.totalOrders} đơn",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimaryDark
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Tổng giá trị tất cả đơn",
                            fontSize = 13.sp,
                            color = TextSecondaryGray
                        )
                        Text(
                            text = OrderCalculator.formatVnd(dailyStats.totalAllAmountVnd),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimaryDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "* Quy tắc: Tổng giá trị tất cả đơn bao gồm cả đơn Giao thành công, Chờ chuyển khoản và Hủy đơn (không tự động trừ đơn hủy, không phải tiền thực nhận). Chạm để xem danh sách.",
                    fontSize = 11.sp,
                    color = TextSecondaryGray
                )
            }
        }

        // 4. Các thẻ thống kê theo 3 trạng thái (Bấm vào từng thẻ để mở danh sách đơn tương ứng - Phần 11)
        Text(
            text = "Chi tiết theo trạng thái (Chạm vào thẻ để lọc đơn)",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = TextPrimaryDark
        )

        StatusOverviewStatCard(
            title = "Đơn giao thành công",
            subtitle = "Đã giao hoàn tất",
            count = dailyStats.deliveredCount,
            amountVnd = dailyStats.deliveredAmountVnd,
            icon = Icons.Default.CheckCircle,
            accentColor = StatusSuccessGreen,
            containerColor = StatusSuccessBg.copy(alpha = 0.55f),
            onClick = { onOpenOrderListWithFilter(OrderStatus.DELIVERED_SUCCESS) }
        )

        StatusOverviewStatCard(
            title = "Đơn chờ chuyển khoản",
            subtitle = "Chưa đồng nghĩa với việc đã nhận tiền",
            count = dailyStats.waitingCount,
            amountVnd = dailyStats.waitingAmountVnd,
            icon = Icons.Default.Schedule,
            accentColor = StatusWaitingYellow,
            containerColor = StatusWaitingBg.copy(alpha = 0.65f),
            onClick = { onOpenOrderListWithFilter(OrderStatus.WAITING_TRANSFER) }
        )

        StatusOverviewStatCard(
            title = "Đơn hủy",
            subtitle = "Giữ nguyên giá tiền gốc, không trừ khỏi tổng giá trị tất cả đơn",
            count = dailyStats.cancelledCount,
            amountVnd = dailyStats.cancelledAmountVnd,
            icon = Icons.Default.Cancel,
            accentColor = StatusCancelledRed,
            containerColor = StatusCancelledBg.copy(alpha = 0.55f),
            onClick = { onOpenOrderListWithFilter(OrderStatus.CANCELLED) }
        )

        // 5. Thẻ tóm tắt Báo cáo khoảng ngày đã chọn (Phần 11)
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = SoftCreamSurface),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onNavigateToReport() }
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Assessment,
                            contentDescription = null,
                            tint = PrimaryYellowDark
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Báo cáo tổng hợp khoảng ngày",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimaryDark
                        )
                    }
                    Text(
                        text = "Xem chi tiết →",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryYellowDark
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Khoảng đang chọn: ${rangeStats.dateOrRangeLabel} (Không giới hạn 100 đơn/tháng)",
                    fontSize = 12.sp,
                    color = TextSecondaryGray
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Tổng số đơn: ${rangeStats.totalOrders} đơn",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Tổng tất cả: ${OrderCalculator.formatVnd(rangeStats.totalAllAmountVnd)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = PrimaryYellowDark
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Thành công: ${rangeStats.deliveredCount} (${OrderCalculator.formatVnd(rangeStats.deliveredAmountVnd)}) • Chờ CK: ${rangeStats.waitingCount} (${OrderCalculator.formatVnd(rangeStats.waitingAmountVnd)}) • Hủy: ${rangeStats.cancelledCount} (${OrderCalculator.formatVnd(rangeStats.cancelledAmountVnd)})",
                    fontSize = 12.sp,
                    color = TextSecondaryGray
                )
            }
        }

        // 6. Lối tắt Quản lý Nhóm đơn gộp & Sao lưu Khôi phục
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedButton(
                onClick = onNavigateToGroups,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Icon(Icons.Default.FolderSpecial, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Đơn gộp", fontWeight = FontWeight.SemiBold)
            }

            OutlinedButton(
                onClick = onNavigateToBackup,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Sao lưu / Khôi phục", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun StatusOverviewStatCard(
    title: String,
    subtitle: String,
    count: Int,
    amountVnd: Long,
    icon: ImageVector,
    accentColor: Color,
    containerColor: Color,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimaryDark
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = TextSecondaryGray
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "$count đơn",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    color = accentColor
                )
                Text(
                    text = OrderCalculator.formatVnd(amountVnd),
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextPrimaryDark
                )
            }
        }
    }
}
