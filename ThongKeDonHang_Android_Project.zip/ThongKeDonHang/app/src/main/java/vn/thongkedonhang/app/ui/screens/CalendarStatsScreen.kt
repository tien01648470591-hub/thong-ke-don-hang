package vn.thongkedonhang.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import vn.thongkedonhang.app.domain.model.OrderItem
import vn.thongkedonhang.app.domain.model.OrderStatus
import vn.thongkedonhang.app.domain.model.OrderSummaryStats
import vn.thongkedonhang.app.domain.util.OrderCalculator
import vn.thongkedonhang.app.ui.components.DateNavigatorBar
import vn.thongkedonhang.app.ui.components.OrderRowCard
import vn.thongkedonhang.app.ui.theme.CardGrayBorder
import vn.thongkedonhang.app.ui.theme.PrimaryYellow
import vn.thongkedonhang.app.ui.theme.PrimaryYellowContainer
import vn.thongkedonhang.app.ui.theme.PrimaryYellowDark
import vn.thongkedonhang.app.ui.theme.StatusCancelledRed
import vn.thongkedonhang.app.ui.theme.StatusSuccessGreen
import vn.thongkedonhang.app.ui.theme.StatusWaitingYellow
import vn.thongkedonhang.app.ui.theme.TextPrimaryDark
import vn.thongkedonhang.app.ui.theme.TextSecondaryGray
import java.io.File
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

/**
 * Trang Lịch và Thống kê theo ngày (Phần 10):
 * - Hiển thị lịch tháng để chọn ngày cần xem.
 * - Có nút chuyển sang ngày trước và ngày tiếp theo.
 * - Hiển thị số lượng đơn trên từng ô ngày (và đánh dấu nếu đạt giới hạn 100/100 đơn).
 * - Hiển thị thống kê & danh sách đơn riêng của ngày đang chọn.
 * - Ngày không có đơn có giao diện trống rõ ràng.
 */
@Composable
fun CalendarStatsScreen(
    selectedDateIso: String,
    dailyStats: OrderSummaryStats,
    dailyOrders: List<OrderItem>,
    orderCountPerDate: Map<String, Int>,
    onSelectDate: (String) -> Unit,
    onPreviousDay: () -> Unit,
    onNextDay: () -> Unit,
    onOrderClick: (String) -> Unit,
    onQuickStatusChange: (String, OrderStatus) -> Unit,
    onOpenGroupClick: (String) -> Unit,
    resolvePhotoFile: (String) -> File
) {
    val isoFormatter = remember { DateTimeFormatter.ofPattern("yyyy-MM-dd") }
    val selectedLocalDate = remember(selectedDateIso) {
        try {
            LocalDate.parse(selectedDateIso, isoFormatter)
        } catch (_: Exception) {
            LocalDate.now()
        }
    }
    var currentYearMonth by remember(selectedLocalDate.year, selectedLocalDate.monthValue) {
        mutableStateOf(YearMonth.of(selectedLocalDate.year, selectedLocalDate.monthValue))
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Thanh điều hướng Ngày trước / Ngày tiếp theo
        DateNavigatorBar(
            selectedDateIso = selectedDateIso,
            orderCountInDay = dailyStats.totalOrders,
            onPreviousDay = onPreviousDay,
            onNextDay = onNextDay,
            onOpenCalendarScreen = {}
        )

        // 2. Bảng Lịch Tháng trực quan
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(onClick = { currentYearMonth = currentYearMonth.minusMonths(1) }) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Tháng trước")
                    }
                    Text(
                        text = "Tháng ${currentYearMonth.monthValue} / ${currentYearMonth.year}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = TextPrimaryDark
                    )
                    IconButton(onClick = { currentYearMonth = currentYearMonth.plusMonths(1) }) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Tháng sau")
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Tiêu đề thứ trong tuần (T2 -> CN)
                val dayHeaders = listOf("T2", "T3", "T4", "T5", "T6", "T7", "CN")
                Row(modifier = Modifier.fillMaxWidth()) {
                    dayHeaders.forEach { label ->
                        Text(
                            text = label,
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = TextSecondaryGray,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                val firstDayOfMonth = currentYearMonth.atDay(1)
                val leadingEmptyCells = firstDayOfMonth.dayOfWeek.value - 1 // Monday = 1 -> 0
                val daysInMonth = currentYearMonth.lengthOfMonth()
                val totalCells = ((leadingEmptyCells + daysInMonth + 6) / 7) * 7

                for (week in 0 until (totalCells / 7)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (dow in 0 until 7) {
                            val cellIndex = week * 7 + dow
                            val dayNumber = cellIndex - leadingEmptyCells + 1
                            if (dayNumber in 1..daysInMonth) {
                                val cellDate = currentYearMonth.atDay(dayNumber)
                                val cellIso = cellDate.format(isoFormatter)
                                val count = orderCountPerDate[cellIso] ?: 0
                                val isSelected = cellIso == selectedDateIso
                                val isLimitFull = count >= 100

                                val bg = when {
                                    isSelected -> PrimaryYellow
                                    count > 0 -> PrimaryYellowContainer.copy(alpha = 0.55f)
                                    else -> Color.White
                                }
                                val borderCol = when {
                                    isSelected -> PrimaryYellowDark
                                    isLimitFull -> StatusCancelledRed
                                    count > 0 -> PrimaryYellow
                                    else -> CardGrayBorder
                                }

                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .padding(2.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(bg)
                                        .border(1.dp, borderCol, RoundedCornerShape(10.dp))
                                        .clickable { onSelectDate(cellIso) }
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = dayNumber.toString(),
                                            fontWeight = if (isSelected || count > 0) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 13.sp,
                                            color = TextPrimaryDark
                                        )
                                        if (count > 0) {
                                            Text(
                                                text = "$count đ",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (isLimitFull) StatusCancelledRed else PrimaryYellowDark
                                            )
                                        }
                                    }
                                }
                            } else {
                                Spacer(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Thống kê nhanh của Ngày đang chọn
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = PrimaryYellowContainer),
            border = BorderStroke(1.dp, PrimaryYellow),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Số liệu ngày ${OrderCalculator.formatIsoToVnDate(selectedDateIso)}",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Tổng số đơn: ${dailyStats.totalOrders}/100 đơn", fontWeight = FontWeight.Bold)
                    Text(
                        text = "Tổng tất cả: ${OrderCalculator.formatVnd(dailyStats.totalAllAmountVnd)}",
                        fontWeight = FontWeight.ExtraBold,
                        color = PrimaryYellowDark
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "• Giao thành công: ${dailyStats.deliveredCount} đơn (${OrderCalculator.formatVnd(dailyStats.deliveredAmountVnd)})",
                    fontSize = 13.sp,
                    color = StatusSuccessGreen,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "• Chờ chuyển khoản: ${dailyStats.waitingCount} đơn (${OrderCalculator.formatVnd(dailyStats.waitingAmountVnd)})",
                    fontSize = 13.sp,
                    color = StatusWaitingYellow,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "• Hủy đơn: ${dailyStats.cancelledCount} đơn (${OrderCalculator.formatVnd(dailyStats.cancelledAmountVnd)})",
                    fontSize = 13.sp,
                    color = StatusCancelledRed,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // 4. Danh sách đơn của ngày đang chọn (hoặc giao diện trống rõ ràng)
        Text(
            text = "Danh sách đơn ngày ${OrderCalculator.formatIsoToVnDate(selectedDateIso)} (${dailyOrders.size} đơn)",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = TextPrimaryDark
        )

        if (dailyOrders.isEmpty()) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, CardGrayBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.EventBusy,
                        contentDescription = null,
                        tint = TextSecondaryGray,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Ngày ${OrderCalculator.formatIsoToVnDate(selectedDateIso)} chưa có đơn hàng nào.",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextPrimaryDark
                    )
                    Text(
                        text = "Hạn mức còn lại trong ngày: 100/100 đơn.",
                        fontSize = 12.sp,
                        color = TextSecondaryGray
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                dailyOrders.forEachIndexed { idx, ord ->
                    OrderRowCard(
                        indexNumber = idx + 1,
                        order = ord,
                        resolvePhotoFile = resolvePhotoFile,
                        onOrderClick = { onOrderClick(ord.id) },
                        onQuickStatusChange = { st -> onQuickStatusChange(ord.id, st) },
                        onOpenGroupClick = { gId -> onOpenGroupClick(gId) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
