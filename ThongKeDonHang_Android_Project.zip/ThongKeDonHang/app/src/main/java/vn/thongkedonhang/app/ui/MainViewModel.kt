package vn.thongkedonhang.app.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import vn.thongkedonhang.app.data.backup.BackupPreviewInfo
import vn.thongkedonhang.app.data.repository.OrderRepository
import vn.thongkedonhang.app.domain.model.DomainResult
import vn.thongkedonhang.app.domain.model.OrderConstants
import vn.thongkedonhang.app.domain.model.OrderGroupSummary
import vn.thongkedonhang.app.domain.model.OrderItem
import vn.thongkedonhang.app.domain.model.OrderStatus
import vn.thongkedonhang.app.domain.model.OrderSummaryStats
import vn.thongkedonhang.app.domain.util.OrderCalculator
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter

enum class SearchScopeMode(val label: String) {
    SELECTED_DATE("Trong ngày đang chọn"),
    REPORT_DATE_RANGE("Trong khoảng ngày báo cáo"),
    ALL_DATES("Tất cả các ngày")
}

data class DuplicateOrderPrompt(
    val existingOrder: OrderItem,
    val message: String
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(
    val repository: OrderRepository
) : ViewModel() {

    private val isoFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    // Ngày đang chọn để xem và thêm đơn (mặc định hôm nay)
    private val _selectedDate = MutableStateFlow(LocalDate.now().format(isoFormatter))
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    // Khoảng ngày báo cáo (mặc định từ đầu tháng hiện tại hoặc 7 ngày gần nhất, tối đa 31 ngày)
    private val _reportStartDate = MutableStateFlow(
        LocalDate.now().withDayOfMonth(1).format(isoFormatter)
    )
    val reportStartDate: StateFlow<String> = _reportStartDate.asStateFlow()

    private val _reportEndDate = MutableStateFlow(LocalDate.now().format(isoFormatter))
    val reportEndDate: StateFlow<String> = _reportEndDate.asStateFlow()

    private val _reportRangeError = MutableStateFlow<String?>(null)
    val reportRangeError: StateFlow<String?> = _reportRangeError.asStateFlow()

    // Tìm kiếm bằng 4 số cuối (Phần 9)
    private val _searchSuffixQuery = MutableStateFlow("")
    val searchSuffixQuery: StateFlow<String> = _searchSuffixQuery.asStateFlow()

    private val _searchScopeMode = MutableStateFlow(SearchScopeMode.SELECTED_DATE)
    val searchScopeMode: StateFlow<SearchScopeMode> = _searchScopeMode.asStateFlow()

    // Bộ lọc trạng thái trên danh sách đơn (null = Tất cả)
    private val _statusFilter = MutableStateFlow<OrderStatus?>(null)
    val statusFilter: StateFlow<OrderStatus?> = _statusFilter.asStateFlow()

    // Cảnh báo trùng mã đơn trong cùng ngày (Phần 3)
    private val _duplicateOrderPrompt = MutableStateFlow<DuplicateOrderPrompt?>(null)
    val duplicateOrderPrompt: StateFlow<DuplicateOrderPrompt?> = _duplicateOrderPrompt.asStateFlow()

    // Thông tin kiểm tra trước khi khôi phục sao lưu (Phần 13)
    private val _pendingRestorePreview = MutableStateFlow<Pair<Uri, BackupPreviewInfo>?>(null)
    val pendingRestorePreview: StateFlow<Pair<Uri, BackupPreviewInfo>?> = _pendingRestorePreview.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _snackbarMessage = MutableSharedFlow<String>()
    val snackbarMessage = _snackbarMessage.asSharedFlow()

    // Danh sách đơn hàng của ngày đang chọn
    val ordersForSelectedDate: StateFlow<List<OrderItem>> = _selectedDate
        .flatMapLatest { date -> repository.observeOrdersByDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Thống kê ngày đang chọn (Phần 7 & Phần 11)
    val selectedDateStats: StateFlow<OrderSummaryStats> = combine(
        _selectedDate,
        ordersForSelectedDate
    ) { date, orders ->
        OrderCalculator.calculateStats(orders, OrderCalculator.formatIsoToVnDate(date))
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        OrderCalculator.calculateStats(emptyList(), "")
    )

    // Danh sách đơn hàng trong khoảng ngày báo cáo (tối đa 1 tháng - Phần 10 & 11)
    val ordersInReportRange: StateFlow<List<OrderItem>> = combine(
        _reportStartDate,
        _reportEndDate
    ) { start, end -> start to end }
        .flatMapLatest { (start, end) ->
            val check = OrderCalculator.validateDateRangeMaxOneMonth(start, end)
            if (check.isSuccess) {
                repository.observeOrdersInRange(start, end)
            } else {
                kotlinx.coroutines.flow.flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Thống kê khoảng ngày báo cáo (không giới hạn tổng số đơn cả tháng ở mức 100 - Phần 11)
    val reportRangeStats: StateFlow<OrderSummaryStats> = combine(
        _reportStartDate,
        _reportEndDate,
        ordersInReportRange
    ) { start, end, orders ->
        val label = "${OrderCalculator.formatIsoToVnDate(start)} - ${OrderCalculator.formatIsoToVnDate(end)}"
        OrderCalculator.calculateStats(orders, label)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        OrderCalculator.calculateStats(emptyList(), "")
    )

    // Tất cả đơn hàng (phục vụ tìm kiếm toàn cục & nhóm đơn)
    val allOrders: StateFlow<List<OrderItem>> = repository.observeAllOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Danh sách đơn đã lọc theo Thanh tìm kiếm 4 số cuối + Bộ lọc trạng thái + Phạm vi ngày (Phần 9)
    val filteredOrderList: StateFlow<List<OrderItem>> = combine(
        ordersForSelectedDate,
        ordersInReportRange,
        allOrders,
        _searchSuffixQuery,
        _searchScopeMode,
        _statusFilter
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        val daily = arr[0] as List<OrderItem>
        @Suppress("UNCHECKED_CAST")
        val range = arr[1] as List<OrderItem>
        @Suppress("UNCHECKED_CAST")
        val all = arr[2] as List<OrderItem>
        val suffix = (arr[3] as String).trim()
        val scope = arr[4] as SearchScopeMode
        val status = arr[5] as OrderStatus?

        val baseList = when (scope) {
            SearchScopeMode.SELECTED_DATE -> daily
            SearchScopeMode.REPORT_DATE_RANGE -> range
            SearchScopeMode.ALL_DATES -> all
        }

        baseList.filter { item ->
            val matchSuffix = if (suffix.isEmpty()) {
                true
            } else {
                OrderCalculator.matchesSuffixQuery(item.orderCode, suffix)
            }
            val matchStatus = status == null || item.status == status
            matchSuffix && matchStatus
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Số lượng đơn theo từng ngày trên lịch
    val orderCountPerDate: StateFlow<Map<String, Int>> = repository.observeOrderCountPerDate()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // Tất cả nhóm đơn gộp kèm thống kê tổng tiền từng nhóm (Phần 8)
    val allGroupSummaries: StateFlow<List<OrderGroupSummary>> = repository.observeAllGroupSummaries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- THAO TÁC CHỌN NGÀY & KHOẢNG NGÀY (PHẦN 10) ---

    fun selectDate(isoDate: String) {
        _selectedDate.value = isoDate
    }

    fun stepSelectedDate(daysDelta: Long) {
        try {
            val current = LocalDate.parse(_selectedDate.value, isoFormatter)
            _selectedDate.value = current.plusDays(daysDelta).format(isoFormatter)
        } catch (_: Exception) {
        }
    }

    fun setReportDateRange(startIso: String, endIso: String) {
        val validation = OrderCalculator.validateDateRangeMaxOneMonth(startIso, endIso)
        if (validation.isFailure) {
            val msg = validation.exceptionOrNull()?.message ?: "Khoảng ngày không hợp lệ."
            _reportRangeError.value = msg
            emitSnackbar(msg)
        } else {
            _reportRangeError.value = null
            _reportStartDate.value = startIso
            _reportEndDate.value = endIso
        }
    }

    // --- TÌM KIẾM 4 SỐ CUỐI & LỌC TRẠNG THÁI (PHẦN 9) ---

    fun updateSearchSuffixQuery(query: String) {
        _searchSuffixQuery.value = query
    }

    fun updateSearchScopeMode(mode: SearchScopeMode) {
        _searchScopeMode.value = mode
    }

    fun updateStatusFilter(status: OrderStatus?) {
        _statusFilter.value = status
    }

    fun clearDuplicatePrompt() {
        _duplicateOrderPrompt.value = null
    }

    // --- THÊM / SỬA / ĐỔI TRẠNG THÁI / XÓA ĐƠN HÀNG ---

    fun createNewOrder(
        orderCode: String,
        amountInput: String,
        status: OrderStatus,
        statDate: String = _selectedDate.value,
        groupId: String? = null,
        note: String = "",
        photoUris: List<Uri> = emptyList(),
        onSuccess: (OrderItem) -> Unit = {}
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val amountVnd = OrderCalculator.parseAmountVnd(amountInput)
            val result = repository.createOrder(
                orderCode = orderCode,
                amountVnd = amountVnd,
                status = status,
                statDate = statDate,
                groupId = groupId,
                note = note,
                photoUris = photoUris
            )
            _isLoading.value = false
            when (result) {
                is DomainResult.Success -> {
                    emitSnackbar("Đã lưu đơn hàng ${result.data.orderCode} (${OrderCalculator.formatVnd(result.data.amountVnd)})")
                    onSuccess(result.data)
                }
                is DomainResult.DuplicateOrderSameDay -> {
                    _duplicateOrderPrompt.value = DuplicateOrderPrompt(
                        existingOrder = result.existingOrder,
                        message = result.message
                    )
                }
                is DomainResult.DailyLimitExceeded -> {
                    emitSnackbar(result.message)
                }
                is DomainResult.PhotoLimitExceeded -> {
                    emitSnackbar(result.message)
                }
                is DomainResult.ValidationError -> {
                    emitSnackbar(result.message)
                }
            }
        }
    }

    fun changeOrderStatus(orderId: String, newStatus: OrderStatus) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, newStatus)
            emitSnackbar("Đã chuyển trạng thái sang: ${newStatus.displayName}")
        }
    }

    fun updateOrderAmount(orderId: String, newAmountInput: String) {
        viewModelScope.launch {
            val amount = OrderCalculator.parseAmountVnd(newAmountInput)
            when (val res = repository.updateOrderAmount(orderId, amount)) {
                is DomainResult.Success -> emitSnackbar("Đã cập nhật giá tiền: ${OrderCalculator.formatVnd(amount)}")
                is DomainResult.ValidationError -> emitSnackbar(res.message)
                else -> {}
            }
        }
    }

    fun saveOrderEdits(
        orderId: String,
        newCode: String,
        newAmountInput: String,
        newStatus: OrderStatus,
        newGroupId: String?,
        newNote: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val amount = OrderCalculator.parseAmountVnd(newAmountInput)
            when (
                val res = repository.updateOrderDetails(
                    orderId = orderId,
                    newOrderCode = newCode,
                    newAmountVnd = amount,
                    newStatus = newStatus,
                    newGroupId = newGroupId,
                    newNote = newNote
                )
            ) {
                is DomainResult.Success -> {
                    emitSnackbar("Đã lưu thay đổi đơn hàng ${res.data.orderCode}")
                    onSuccess()
                }
                is DomainResult.DuplicateOrderSameDay -> {
                    _duplicateOrderPrompt.value = DuplicateOrderPrompt(
                        existingOrder = res.existingOrder,
                        message = res.message
                    )
                }
                is DomainResult.ValidationError -> emitSnackbar(res.message)
                else -> {}
            }
        }
    }

    fun deleteOrder(orderId: String, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteOrder(orderId)
            emitSnackbar("Đã xóa đơn hàng và tính lại thống kê.")
            onDeleted()
        }
    }

    // --- QUẢN LÝ ẢNH ĐÍNH KÈM (TỐI ĐA 3 ẢNH/ĐƠN - PHẦN 5) ---

    fun addPhotoToOrder(orderId: String, uri: Uri) {
        viewModelScope.launch {
            when (val res = repository.addPhotoToExistingOrder(orderId, uri)) {
                is DomainResult.Success -> emitSnackbar("Đã đính kèm ảnh thành công.")
                is DomainResult.PhotoLimitExceeded -> emitSnackbar(res.message)
                is DomainResult.ValidationError -> emitSnackbar(res.message)
                else -> {}
            }
        }
    }

    fun replacePhotoInOrder(orderId: String, oldPhotoId: String, newUri: Uri) {
        viewModelScope.launch {
            when (val res = repository.replaceOrderPhoto(orderId, oldPhotoId, newUri)) {
                is DomainResult.Success -> emitSnackbar("Đã thay thế ảnh thành công.")
                is DomainResult.ValidationError -> emitSnackbar(res.message)
                else -> {}
            }
        }
    }

    fun deletePhotoFromOrder(orderId: String, photoId: String) {
        viewModelScope.launch {
            when (val res = repository.deleteSingleOrderPhoto(orderId, photoId)) {
                is DomainResult.Success -> emitSnackbar("Đã xóa ảnh đính kèm.")
                is DomainResult.ValidationError -> emitSnackbar(res.message)
                else -> {}
            }
        }
    }

    fun resolvePhotoFile(relativePath: String): File {
        return repository.resolvePhotoFile(relativePath)
    }

    // --- QUẢN LÝ NHÓM ĐƠN GỘP (PHẦN 8) ---

    fun createGroup(groupName: String, note: String, onCreated: (String) -> Unit = {}) {
        viewModelScope.launch {
            when (
                val res = repository.createOrderGroup(
                    groupName = groupName,
                    note = note,
                    createdDate = _selectedDate.value
                )
            ) {
                is DomainResult.Success -> {
                    emitSnackbar("Đã tạo nhóm đơn gộp: ${res.data.groupName}")
                    onCreated(res.data.groupId)
                }
                is DomainResult.ValidationError -> emitSnackbar(res.message)
                else -> {}
            }
        }
    }

    fun renameGroup(groupId: String, newName: String, newNote: String) {
        viewModelScope.launch {
            when (val res = repository.renameOrderGroup(groupId, newName, newNote)) {
                is DomainResult.Success -> emitSnackbar("Đã cập nhật tên nhóm.")
                is DomainResult.ValidationError -> emitSnackbar(res.message)
                else -> {}
            }
        }
    }

    fun assignOrderToGroup(orderId: String, groupId: String?) {
        viewModelScope.launch {
            repository.assignOrderToGroup(orderId, groupId)
            val msg = if (groupId == null) "Đã tách đơn khỏi nhóm." else "Đã cập nhật nhóm cho đơn hàng."
            emitSnackbar(msg)
        }
    }

    fun deleteGroupKeepingOrders(groupId: String) {
        viewModelScope.launch {
            repository.deleteGroupKeepingOrders(groupId)
            emitSnackbar("Đã xóa nhóm đơn gộp (các đơn hàng bên trong vẫn được giữ nguyên).")
        }
    }

    // --- SAO LƯU & KHÔI PHỤC DỮ LIỆU (PHẦN 13) ---

    fun exportBackupToUri(destUri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.exportBackup(destUri)
            _isLoading.value = false
            result.onSuccess { info ->
                emitSnackbar(
                    "Sao lưu thành công: ${info.totalOrders} đơn, ${info.totalGroups} nhóm, ${info.totalPhotos} ảnh."
                )
            }.onFailure { err ->
                emitSnackbar("Lỗi khi sao lưu: ${err.message}")
            }
        }
    }

    fun inspectBackupBeforeRestore(sourceUri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.validateBackup(sourceUri)
            _isLoading.value = false
            result.onSuccess { preview ->
                _pendingRestorePreview.value = sourceUri to preview
            }.onFailure { err ->
                emitSnackbar("Bản sao lưu không hợp lệ: ${err.message}")
            }
        }
    }

    fun cancelPendingRestore() {
        _pendingRestorePreview.value = null
    }

    fun confirmAndExecuteRestore() {
        val pending = _pendingRestorePreview.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            _pendingRestorePreview.value = null
            val result = repository.restoreBackup(pending.first)
            _isLoading.value = false
            result.onSuccess { info ->
                emitSnackbar(
                    "Khôi phục hoàn tất: ${info.totalOrders} đơn hàng, ${info.totalGroups} nhóm, ${info.totalPhotos} ảnh."
                )
            }.onFailure { err ->
                emitSnackbar("Khôi phục thất bại: ${err.message}")
            }
        }
    }

    fun emitSnackbar(message: String) {
        viewModelScope.launch {
            _snackbarMessage.emit(message)
        }
    }

    class Factory(private val repository: OrderRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(repository) as T
        }
    }
}
