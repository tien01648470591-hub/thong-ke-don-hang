package vn.thongkedonhang.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import vn.thongkedonhang.app.domain.model.OrderItem
import vn.thongkedonhang.app.domain.model.OrderSummaryStats
import vn.thongkedonhang.app.domain.util.OrderCalculator
import vn.thongkedonhang.app.ui.theme.CardGrayBorder
import vn.thongkedonhang.app.ui.theme.PrimaryYellow
import vn.thongkedonhang.app.ui.theme.PrimaryYellowContainer
import vn.thongkedonhang.app.ui.theme.PrimaryYellowDark
import vn.thongkedonhang.app.ui.theme.SoftCreamSurface
import vn.thongkedonhang.app.ui.theme.StatusCancelledBg
import vn.thongkedonhang.app.ui.theme.StatusCancelledRed
import vn.thongkedonhang.app.ui.theme.StatusSuccessBg
import vn.thongkedonhang.app.ui.theme.StatusSuccessGreen
import vn.thongkedonhang.app.ui.theme.StatusWaitingBg
import vn.thongkedonhang.app.ui.theme.StatusWaitingYellow
import vn.thongkedonhang.app.ui.theme.TextPrimaryDark
import vn.thongkedonhang.app.ui.theme.TextSecondaryGray
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/**
 * Trang Báo cáo Tổng tiền (Phần 7, 10, 11):
 * - Cho phép xem báo cáo của 1 ngày hoặc khoảng thời gian tối đa 1 tháng (31 ngày).
 * - Không giới hạn tổng số đơn của cả tháng ở mức 100 (giới hạn 100 đơn chỉ áp dụng cho từng ngày riêng biệt).
 * - Phân biệt rõ ràng 4 chỉ số bắt buộc:
 *   1. Tổng giá trị tất cả đơn (Bao gồm Giao thành công + Chờ chuyển khoản + Hủy đơn; KHÔNG trừ đơn hủy; KHÔNG gọi là tiền thực nhận).
 *   2. Tổng giá trị đơn giao thành công.
 *   3. Tổng giá trị đơn chờ chuyển khoản (Chưa đồng nghĩa với việc đã nhận tiền).
 *   4. Tổng giá trị đơn hủy (Giữ nguyên giá tiền đã nhập).
 */
@Composable
fun TotalReportScreen(
    selectedDateIso: String,
    dailyStats: OrderSummaryStats,
    reportStartDateIso: String,
    reportEndDateIso: String,
    reportRangeError: String?,
    rangeStats: OrderSummaryStats,
    ordersInRange: List<OrderItem>,
    onApplyDateRange: (startIso: String, endIso: String) -> Unit
) {
    val isoFormatter = remember { DateTimeFormatter.ofPattern("yyyy-MM-dd") }
    var startInput by remember(reportStartDateIso) { mutableStateOf(reportStartDateIso) }
    var endInput by remember(reportEndDateIso) { mutableStateOf(reportEndDateIso) }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Báo cáo Tổng tiền & Phân loại Trạng thái",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 18.sp,
            color = TextPrimaryDark
        )

        // 1. Khối Báo cáo của riêng Ngày đang chọn
        ReportBreakdownCard(
            headerTitle = "1. BÁO CÁO NGÀY ĐANG CHỌN (${OrderCalculator.formatIsoToVnDate(selectedDateIso)})",
            subtitle = "Giới hạn ngày: ${dailyStats.totalOrders}/100 đơn (Còn lại ${dailyStats.remainingDailyQuota} đơn)",
            stats = dailyStats
        )

        // 2. Bộ chọn Khoảng thời gian thống kê (Tối đa 1 tháng = 31 ngày)
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Chọn khoảng ngày thống kê (Tối đa 1 tháng / 31 ngày)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Các nút chọn nhanh khoảng thời gian hợp lệ
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = {
                            val today = LocalDate.now()
                            val s = today.format(isoFormatter)
                            startInput = s
                            endInput = s
                            onApplyDateRange(s, s)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Hôm nay", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = {
                            val end = LocalDate.now()
                            val start = end.minusDays(6)
                            startInput = start.format(isoFormatter)
                            endInput = end.format(isoFormatter)
                            onApplyDateRange(startInput, endInput)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("7 ngày qua", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = {
                            val end = LocalDate.now()
                            val start = end.minusDays(29)
                            startInput = start.format(isoFormatter)
                            endInput = end.format(isoFormatter)
                            onApplyDateRange(startInput, endInput)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("30 ngày qua", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = startInput,
                        onValueChange = { startInput = it.trim() },
                        label = { Text("Từ ngày (yyyy-MM-dd)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = endInput,
                        onValueChange = { endInput = it.trim() },
                        label = { Text("Đến ngày (yyyy-MM-dd)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                if (reportRangeError != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = reportRangeError,
                        color = StatusCancelledRed,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { onApplyDateRange(startInput, endInput) },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryYellow),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Áp dụng khoảng ngày báo cáo",
                        color = TextPrimaryDark,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 3. Khối Báo cáo Tổng hợp Khoảng ngày đã chọn
        ReportBreakdownCard(
            headerTitle = "2. BÁO CÁO KHOẢNG NGÀY (${rangeStats.dateOrRangeLabel})",
            subtitle = "Tổng số đơn trong khoảng ngày không giới hạn ở mức 100 đơn/tháng",
            stats = rangeStats
        )

        // 4. Bảng thống kê chi tiết theo từng ngày trong khoảng đã chọn
        val ordersByDate = remember(ordersInRange) {
            ordersInRange.groupBy { it.statDate }.toSortedMap(compareByDescending { it })
        }

        if (ordersByDate.isNotEmpty()) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, CardGrayBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Chi tiết theo từng ngày trong khoảng đã chọn",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimaryDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    ordersByDate.forEach { (dateIso, dayOrders) ->
                        val st = OrderCalculator.calculateStats(dayOrders, dateIso)
                        Surface(
                            color = SoftCreamSurface,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, CardGrayBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "Ngày ${OrderCalculator.formatIsoToVnDate(dateIso)} (${st.totalOrders}/100 đơn)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = OrderCalculator.formatVnd(st.totalAllAmountVnd),
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.sp,
                                        color = PrimaryYellowDark
                                    )
                                }
                                Text(
                                    text = "Thành công: ${st.deliveredCount} (${OrderCalculator.formatVnd(st.deliveredAmountVnd)}) • Chờ CK: ${st.waitingCount} (${OrderCalculator.formatVnd(st.waitingAmountVnd)}) • Hủy: ${st.cancelledCount} (${OrderCalculator.formatVnd(st.cancelledAmountVnd)})",
                                    fontSize = 11.sp,
                                    color = TextSecondaryGray
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
    }
}

@Composable
private fun ReportBreakdownCard(
    headerTitle: String,
    subtitle: String,
    stats: OrderSummaryStats
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, PrimaryYellow),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = headerTitle,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = PrimaryYellowDark
            )
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = TextSecondaryGray
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Tổng giá trị tất cả đơn (Không gọi là tiền thực nhận, không trừ đơn hủy)
            Surface(
                color = PrimaryYellowContainer,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Tổng giá trị tất cả đơn (${stats.totalOrders} đơn)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimaryDark
                            )
                            Text(
                                text = "Bao gồm Giao thành công + Chờ chuyển khoản + Hủy đơn (Không phải tiền thực nhận)",
                                fontSize = 11.sp,
                                color = TextSecondaryGray
                            )
                        }
                        Text(
                            text = OrderCalculator.formatVnd(stats.totalAllAmountVnd),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = TextPrimaryDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 1. Tổng giá trị đơn giao thành công
            ReportStatusRow(
                label = "Tổng giá trị đơn giao thành công",
                note = "Số lượng: ${stats.deliveredCount} đơn",
                amountVnd = stats.deliveredAmountVnd,
                textColor = StatusSuccessGreen,
                bgColor = StatusSuccessBg.copy(alpha = 0.5f)
            )

            Spacer(modifier = Modifier.height(6.dp))

            // 2. Tổng giá trị đơn chờ chuyển khoản
            ReportStatusRow(
                label = "Tổng giá trị đơn chờ chuyển khoản",
                note = "Số lượng: ${stats.waitingCount} đơn (Chưa đồng nghĩa đã nhận tiền)",
                amountVnd = stats.waitingAmountVnd,
                textColor = StatusWaitingYellow,
                bgColor = StatusWaitingBg.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(6.dp))

            // 3. Tổng giá trị đơn hủy
            ReportStatusRow(
                label = "Tổng giá trị đơn hủy",
                note = "Số lượng: ${stats.cancelledCount} đơn (Giữ nguyên giá tiền, không trừ khỏi tổng tất cả đơn)",
                amountVnd = stats.cancelledAmountVnd,
                textColor = StatusCancelledRed,
                bgColor = StatusCancelledBg.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
private fun ReportStatusRow(
    label: String,
    note: String,
    amountVnd: Long,
    textColor: Color,
    bgColor: Color
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = textColor
                )
                Text(
                    text = note,
                    fontSize = 11.sp,
                    color = TextSecondaryGray
                )
            }
            Text(
                text = OrderCalculator.formatVnd(amountVnd),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                color = TextPrimaryDark
            )
        }
    }
}
