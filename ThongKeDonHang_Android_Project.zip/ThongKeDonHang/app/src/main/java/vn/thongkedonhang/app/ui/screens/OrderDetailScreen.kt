package vn.thongkedonhang.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import vn.thongkedonhang.app.data.storage.PhotoStorageManager
import vn.thongkedonhang.app.domain.model.OrderConstants
import vn.thongkedonhang.app.domain.model.OrderGroupSummary
import vn.thongkedonhang.app.domain.model.OrderItem
import vn.thongkedonhang.app.domain.model.OrderStatus
import vn.thongkedonhang.app.domain.util.OrderCalculator
import vn.thongkedonhang.app.ui.components.FullScreenPhotoDialog
import vn.thongkedonhang.app.ui.components.StatusBadge
import vn.thongkedonhang.app.ui.components.StatusSelectorGroup
import vn.thongkedonhang.app.ui.theme.CardGrayBorder
import vn.thongkedonhang.app.ui.theme.PrimaryYellow
import vn.thongkedonhang.app.ui.theme.PrimaryYellowContainer
import vn.thongkedonhang.app.ui.theme.PrimaryYellowDark
import vn.thongkedonhang.app.ui.theme.StatusCancelledRed
import vn.thongkedonhang.app.ui.theme.TextPrimaryDark
import vn.thongkedonhang.app.ui.theme.TextSecondaryGray
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderDetailScreen(
    order: OrderItem?,
    groups: List<OrderGroupSummary>,
    photoStorageManager: PhotoStorageManager,
    onBack: () -> Unit,
    onStatusChange: (OrderStatus) -> Unit,
    onSaveEdits: (
        newCode: String,
        newAmountText: String,
        newStatus: OrderStatus,
        newGroupId: String?,
        newNote: String
    ) -> Unit,
    onAddPhoto: (Uri) -> Unit,
    onReplacePhoto: (String, Uri) -> Unit,
    onDeletePhoto: (String) -> Unit,
    onDeleteOrder: () -> Unit,
    onOpenGroup: (String) -> Unit,
    onShowMessage: (String) -> Unit
) {
    if (order == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Không tìm thấy thông tin đơn hàng.", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(onClick = onBack) {
                    Text("Quay lại")
                }
            }
        }
        return
    }

    val scrollState = rememberScrollState()
    var editCode by remember(order.id) { mutableStateOf(order.orderCode) }
    var editAmount by remember(order.id, order.amountVnd) { mutableStateOf(order.amountVnd.toString()) }
    var editNote by remember(order.id, order.note) { mutableStateOf(order.note) }
    var editGroupId by remember(order.id, order.groupId) { mutableStateOf(order.groupId) }

    var showDeleteConfirm by remember { mutableStateOf(false) }
    var fullScreenPhotoFile by remember { mutableStateOf<File?>(null) }
    var photoIdToReplace by remember { mutableStateOf<String?>(null) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

    LaunchedEffect(order.orderCode, order.amountVnd, order.note, order.groupId) {
        editCode = order.orderCode
        editAmount = order.amountVnd.toString()
        editNote = order.note
        editGroupId = order.groupId
    }

    val addPhotoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onAddPhoto(uri)
        }
    }

    val replacePhotoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        val targetId = photoIdToReplace
        if (uri != null && targetId != null) {
            onReplacePhoto(targetId, uri)
        }
        photoIdToReplace = null
    }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) {
            onAddPhoto(uri)
        }
    }

    if (fullScreenPhotoFile != null) {
        FullScreenPhotoDialog(
            photoFile = fullScreenPhotoFile!!,
            orderCode = order.orderCode,
            onDismiss = { fullScreenPhotoFile = null }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Xác nhận xóa đơn hàng", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Bạn có chắc chắn muốn xóa đơn hàng "${order.orderCode}" (${OrderCalculator.formatVnd(order.amountVnd)}) không?

Ảnh đính kèm của riêng đơn này sẽ được xóa an toàn và thống kê ngày sẽ được tính lại."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteOrder()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusCancelledRed)
                ) {
                    Text("Xóa đơn", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Hủy bỏ")
                }
            }
        )
    }

    val dateTimeStr = remember(order.createdAtMillis, order.statDate) {
        val tf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        "${OrderCalculator.formatIsoToVnDate(order.statDate)} lúc ${tf.format(Date(order.createdAtMillis))}"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Thanh tiêu đề quay lại
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedButton(onClick = onBack, shape = RoundedCornerShape(10.dp)) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Quay lại", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Quay lại")
            }

            StatusBadge(status = order.status)
        }

        // Thẻ thông tin chính của đơn
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PrimaryYellowContainer),
            border = BorderStroke(1.5.dp, PrimaryYellow),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Mã đơn đầy đủ:",
                    fontSize = 12.sp,
                    color = TextSecondaryGray
                )
                Text(
                    text = order.orderCode,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Giá tiền hiện tại: ${OrderCalculator.formatVnd(order.amountVnd)}",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryYellowDark
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Ngày thống kê: $dateTimeStr",
                    fontSize = 13.sp,
                    color = TextSecondaryGray
                )
                if (order.groupId != null && !order.groupName.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { onOpenGroup(order.groupId) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.FolderSpecial, contentDescription = null, tint = PrimaryYellowDark)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Thuộc nhóm: ${order.groupName} (Bấm xem các đơn cùng nhóm)",
                            color = TextPrimaryDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Đổi trạng thái tức thì (Phần 6: Giữ nguyên giá tiền, mã đơn và ảnh)
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Đổi trạng thái đơn hàng (Lưu ngay lập tức)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextPrimaryDark
                )
                Text(
                    text = "Khi đổi trạng thái (kể cả sang Hủy đơn), giá tiền ${OrderCalculator.formatVnd(order.amountVnd)} và ảnh đính kèm vẫn giữ nguyên.",
                    fontSize = 12.sp,
                    color = TextSecondaryGray
                )
                Spacer(modifier = Modifier.height(10.dp))
                StatusSelectorGroup(
                    selectedStatus = order.status,
                    onStatusSelected = { newStatus ->
                        if (newStatus != order.status) {
                            onStatusChange(newStatus)
                        }
                    }
                )
            }
        }

        // Quản lý ảnh đính kèm (Phần 5: Xem ảnh lớn, Thay thế ảnh, Xóa ảnh riêng lẻ, Thêm tối đa 3 ảnh)
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                val canAddPhoto = order.photos.size < OrderConstants.MAX_PHOTOS_PER_ORDER
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Ảnh đính kèm (${order.photos.size}/3 ảnh)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimaryDark
                    )
                    if (!canAddPhoto) {
                        Text(
                            text = "Đã đạt tối đa 3 ảnh",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusCancelledRed
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (order.photos.isEmpty()) {
                    Text(
                        text = "Đơn hàng này chưa có ảnh đính kèm.",
                        fontSize = 13.sp,
                        color = TextSecondaryGray
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        order.photos.forEachIndexed { idx, photo ->
                            val file = photoStorageManager.resolvePhotoFile(photo.relativePath)
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, CardGrayBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(10.dp)
                                ) {
                                    AsyncImage(
                                        model = file,
                                        contentDescription = "Ảnh ${idx + 1}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(76.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .border(1.dp, CardGrayBorder, RoundedCornerShape(10.dp))
                                            .clickable { fullScreenPhotoFile = file }
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Ảnh #${idx + 1}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = "Chạm vào ảnh để phóng to",
                                            fontSize = 12.sp,
                                            color = TextSecondaryGray
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedButton(
                                                onClick = { fullScreenPhotoFile = file },
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.ZoomIn, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Xem lớn", fontSize = 12.sp)
                                            }
                                            OutlinedButton(
                                                onClick = {
                                                    photoIdToReplace = photo.photoId
                                                    replacePhotoPickerLauncher.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                    )
                                                },
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Thay ảnh", fontSize = 12.sp)
                                            }
                                            IconButton(
                                                onClick = { onDeletePhoto(photo.photoId) }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Xóa ảnh này",
                                                    tint = StatusCancelledRed
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = {
                            if (!canAddPhoto) {
                                onShowMessage("Đơn hàng đã có đủ 3 ảnh. Không thể thêm ảnh thứ 4.")
                            } else {
                                val (_, uri) = photoStorageManager.createTempCameraCaptureUri()
                                pendingCameraUri = uri
                                takePictureLauncher.launch(uri)
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Chụp thêm ảnh")
                    }

                    OutlinedButton(
                        onClick = {
                            if (!canAddPhoto) {
                                onShowMessage("Đơn hàng đã có đủ 3 ảnh. Không thể thêm ảnh thứ 4.")
                            } else {
                                addPhotoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Chọn ảnh thư viện")
                    }
                }
            }
        }

        // Chỉnh sửa Giá tiền, Mã đơn, Nhóm đơn gộp & Ghi chú (Phần 4 & Phần 12)
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardGrayBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Chỉnh sửa thông tin & Giá tiền đơn hàng",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = editCode,
                    onValueChange = { editCode = it },
                    label = { Text("Mã đơn hàng") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = editAmount,
                    onValueChange = { raw -> editAmount = raw.filter { it.isDigit() } },
                    label = { Text("Giá tiền (VNĐ)") },
                    suffix = { Text("₫") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                var groupMenuExpanded by remember { mutableStateOf(false) }
                val currentGroupName = groups.firstOrNull { it.groupId == editGroupId }?.groupName
                    ?: "Không thuộc nhóm nào (Đơn lẻ)"

                ExposedDropdownMenuBox(
                    expanded = groupMenuExpanded,
                    onExpandedChange = { groupMenuExpanded = !groupMenuExpanded }
                ) {
                    OutlinedTextField(
                        value = currentGroupName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Nhóm đơn gộp") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = groupMenuExpanded)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = groupMenuExpanded,
                        onDismissRequest = { groupMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Tách khỏi nhóm (Đơn lẻ)") },
                            onClick = {
                                editGroupId = null
                                groupMenuExpanded = false
                            }
                        )
                        groups.forEach { grp ->
                            DropdownMenuItem(
                                text = { Text("${grp.groupName} (${grp.orders.size} đơn)") },
                                onClick = {
                                    editGroupId = grp.groupId
                                    groupMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = editNote,
                    onValueChange = { editNote = it },
                    label = { Text("Ghi chú") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        onSaveEdits(
                            editCode,
                            editAmount,
                            order.status,
                            editGroupId,
                            editNote
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryYellow),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, tint = TextPrimaryDark)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Cập nhật thông tin & Giá tiền",
                        color = TextPrimaryDark,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Nút Xóa đơn hàng (Có hộp thoại xác nhận)
        OutlinedButton(
            onClick = { showDeleteConfirm = true },
            border = BorderStroke(1.5.dp, StatusCancelledRed),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Icon(Icons.Default.Delete, contentDescription = null, tint = StatusCancelledRed)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Xóa đơn hàng này",
                color = StatusCancelledRed,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
