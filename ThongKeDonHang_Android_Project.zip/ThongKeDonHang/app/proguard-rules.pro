# Keep Room entities & DAOs
-keep class vn.thongkedonhang.app.data.local.entity.** { *; }
-keep class vn.thongkedonhang.app.domain.model.** { *; }
-dontwarn com.google.mlkit.**
