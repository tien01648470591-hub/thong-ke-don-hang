package vn.thongkedonhang.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import vn.thongkedonhang.app.domain.model.OrderItem
import vn.thongkedonhang.app.domain.model.OrderStatus
import vn.thongkedonhang.app.domain.util.OrderCalculator
import vn.thongkedonhang.app.ui.theme.CardGrayBorder
import vn.thongkedonhang.app.ui.theme.PrimaryYellow
import vn.thongkedonhang.app.ui.theme.PrimaryYellowContainer
import vn.thongkedonhang.app.ui.theme.PrimaryYellowDark
import vn.thongkedonhang.app.ui.theme.StatusCancelledBg
import vn.thongkedonhang.app.ui.theme.StatusCancelledRed
import vn.thongkedonhang.app.ui.theme.StatusSuccessBg
import vn.thongkedonhang.app.ui.theme.StatusSuccessGreen
import vn.thongkedonhang.app.ui.theme.StatusWaitingBg
import vn.thongkedonhang.app.ui.theme.StatusWaitingYellow
import vn.thongkedonhang.app.ui.theme.TextPrimaryDark
import vn.thongkedonhang.app.ui.theme.TextSecondaryGray
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun OrderStatus.statusIcon(): ImageVector = when (this) {
    OrderStatus.DELIVERED_SUCCESS -> Icons.Default.CheckCircle
    OrderStatus.WAITING_TRANSFER -> Icons.Default.Schedule
    OrderStatus.CANCELLED -> Icons.Default.Cancel
}

fun OrderStatus.foregroundColor(): Color = when (this) {
    OrderStatus.DELIVERED_SUCCESS -> StatusSuccessGreen
    OrderStatus.WAITING_TRANSFER -> StatusWaitingYellow
    OrderStatus.CANCELLED -> StatusCancelledRed
}

fun OrderStatus.backgroundColor(): Color = when (this) {
    OrderStatus.DELIVERED_SUCCESS -> StatusSuccessBg
    OrderStatus.WAITING_TRANSFER -> StatusWaitingBg
    OrderStatus.CANCELLED -> StatusCancelledBg
}

/**
 * Nhãn trạng thái kết hợp màu sắc + biểu tượng + chữ theo Phần 2 & Phần 6.
 */
@Composable
fun StatusBadge(
    status: OrderStatus,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val fg = status.foregroundColor()
    val bg = status.backgroundColor()
    Surface(
        color = bg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, fg.copy(alpha = 0.4f)),
        modifier = modifier.then(
            if (onClick != null) Modifier.clickable { onClick() } else Modifier
        )
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Icon(
                imageVector = status.statusIcon(),
                contentDescription = status.displayName,
                tint = fg,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = status.displayName,
                color = fg,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

/**
 * Bộ 3 nút chọn trạng thái lớn dễ bấm bằng một tay (Phần 2 & Phần 6).
 */
@Composable
fun StatusSelectorGroup(
    selectedStatus: OrderStatus,
    onStatusSelected: (OrderStatus) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OrderStatus.entries.forEach { status ->
            val isSelected = status == selectedStatus
            val fg = status.foregroundColor()
            val bg = if (isSelected) status.backgroundColor() else Color.White
            val borderColor = if (isSelected) fg else CardGrayBorder

            Surface(
                color = bg,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(if (isSelected) 2.dp else 1.dp, borderColor),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .clickable { onStatusSelected(status) }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    Icon(
                        imageVector = status.statusIcon(),
                        contentDescription = status.displayName,
                        tint = fg,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = status.displayName,
                        color = if (isSelected) fg else TextPrimaryDark,
                        fontSize = 15.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.weight(1f)
                    )
                    if (isSelected) {
                        Text(
                            text = "Đang chọn ✓",
                            color = fg,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

/**
 * Thanh chọn ngày nhanh ở đầu trang (Ngày trước / Ngày đang xem / Ngày tiếp theo + Hạn mức 100 đơn/ngày).
 */
@Composable
fun DateNavigatorBar(
    selectedDateIso: String,
    orderCountInDay: Int,
    onPreviousDay: () -> Unit,
    onNextDay: () -> Unit,
    onOpenCalendarScreen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val remaining = (100 - orderCountInDay).coerceAtLeast(0)
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = PrimaryYellowContainer.copy(alpha = 0.65f)),
        border = BorderStroke(1.dp, PrimaryYellow.copy(alpha = 0.5f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            IconButton(
                onClick = onPreviousDay,
                modifier = Modifier.size(44.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ChevronLeft,
                    contentDescription = "Ngày trước",
                    tint = TextPrimaryDark
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .weight(1f)
                    .clickable { onOpenCalendarScreen() }
                    .padding(vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = PrimaryYellowDark,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Ngày: ${OrderCalculator.formatIsoToVnDate(selectedDateIso)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextPrimaryDark
                    )
                }
                Text(
                    text = "Đã tạo: $orderCountInDay/100 đơn • Còn lại: $remaining đơn",
                    fontSize = 12.sp,
                    color = if (remaining == 0) StatusCancelledRed else TextSecondaryGray,
                    fontWeight = if (remaining == 0) FontWeight.Bold else FontWeight.Normal
                )
            }

            IconButton(
                onClick = onNextDay,
                modifier = Modifier.size(44.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Ngày tiếp theo",
                    tint = TextPrimaryDark
                )
            }
        }
    }
}

/**
 * Thẻ hiển thị từng dòng đơn hàng trong Danh sách (Phần 9 & Phần 12):
 * Hiển thị: Số thứ tự, Mã đơn đầy đủ (nổi bật 4 số cuối), Giá tiền VNĐ, Trạng thái màu,
 * Ngày và thời điểm tạo, Biểu tượng có ảnh + ảnh thu nhỏ, Tên nhóm đơn gộp (cho phép bấm mở nhóm).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OrderRowCard(
    indexNumber: Int,
    order: OrderItem,
    resolvePhotoFile: (String) -> File,
    onOrderClick: () -> Unit,
    onQuickStatusChange: (OrderStatus) -> Unit,
    onOpenGroupClick: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val timeFormatter = SimpleDateFormat("HH:mm", Locale.getDefault())
    val timeStr = timeFormatter.format(Date(order.createdAtMillis))
    val dateVn = OrderCalculator.formatIsoToVnDate(order.statDate)

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, CardGrayBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onOrderClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Số thứ tự
                    Surface(
                        color = PrimaryYellowContainer,
                        shape = CircleShape
                    ) {
                        Text(
                            text = "#$indexNumber",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TextPrimaryDark,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))

                    // Mã đơn đầy đủ + làm nổi bật 4 ký tự cuối
                    val code = order.orderCode
                    val annotatedCode = buildAnnotatedString {
                        if (code.length > 4) {
                            append(code.dropLast(4))
                            withStyle(
                                SpanStyle(
                                    color = PrimaryYellowDark,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            ) {
                                append(code.takeLast(4))
                            }
                        } else {
                            withStyle(
                                SpanStyle(
                                    color = PrimaryYellowDark,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            ) {
                                append(code)
                            }
                        }
                    }
                    Text(
                        text = annotatedCode,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Giá tiền VNĐ
                Text(
                    text = OrderCalculator.formatVnd(order.amountVnd),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimaryDark
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Trạng thái hiện tại
                StatusBadge(status = order.status)

                // Ngày & Giờ tạo
                Text(
                    text = "$dateVn • $timeStr",
                    fontSize = 12.sp,
                    color = TextSecondaryGray
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Nhóm đơn gộp + Biểu tượng ảnh thu nhỏ
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (order.groupId != null && !order.groupName.isNullOrBlank()) {
                    Surface(
                        color = Color(0xFFEFF6FF),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFF93C5FD)),
                        modifier = Modifier.clickable {
                            onOpenGroupClick?.invoke(order.groupId)
                        }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FolderSpecial,
                                contentDescription = "Nhóm đơn gộp",
                                tint = Color(0xFF1D4ED8),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Nhóm: ${order.groupName} (Xem nhóm)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1D4ED8)
                            )
                        }
                    }
                }

                if (order.photos.isNotEmpty()) {
                    Surface(
                        color = SoftCreamSurface,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, PrimaryYellow.copy(alpha = 0.5f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoLibrary,
                                contentDescription = "Đơn có ảnh",
                                tint = PrimaryYellowDark,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${order.photos.size}/3 ảnh",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimaryDark
                            )
                        }
                    }
                }
            }

            // Hiển thị ảnh thu nhỏ nếu có (Phần 9)
            if (order.photos.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    order.photos.forEach { photo ->
                        val file = resolvePhotoFile(photo.relativePath)
                        AsyncImage(
                            model = file,
                            contentDescription = "Ảnh đơn ${order.orderCode}",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, CardGrayBorder, RoundedCornerShape(8.dp))
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Hàng nút đổi trạng thái nhanh 1 chạm
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OrderStatus.entries.forEach { targetStatus ->
                    val isCurrent = order.status == targetStatus
                    OutlinedButton(
                        onClick = {
                            if (!isCurrent) onQuickStatusChange(targetStatus)
                        },
                        enabled = !isCurrent,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(
                            1.dp,
                            if (isCurrent) targetStatus.foregroundColor() else CardGrayBorder
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                    ) {
                        Text(
                            text = targetStatus.shortLabel,
                            fontSize = 11.sp,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                            color = if (isCurrent) targetStatus.foregroundColor() else TextSecondaryGray,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

/**
 * Hộp thoại cảnh báo khi mã đơn đã tồn tại trong cùng ngày (Phần 3):
 * Cho phép người dùng bấm "Mở đơn đã tồn tại" để tránh tạo bản ghi trùng ngoài ý muốn.
 */
@Composable
fun DuplicateOrderWarningDialog(
    message: String,
    existingOrderCode: String,
    onOpenExistingOrder: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Cảnh báo trùng mã đơn trong ngày",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                text = "$message

Bạn có muốn mở đơn hàng "$existingOrderCode" đã tồn tại để kiểm tra hoặc chỉnh sửa không?"
            )
        },
        confirmButton = {
            Button(
                onClick = onOpenExistingOrder,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryYellow)
            ) {
                Text("Mở đơn đã tồn tại", color = TextPrimaryDark, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Đóng")
            }
        }
    )
}

/**
 * Hộp thoại xem ảnh phóng to trong Chi tiết đơn hàng (Phần 5).
 */
@Composable
fun FullScreenPhotoDialog(
    photoFile: File,
    orderCode: String,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.92f))
                .padding(16.dp)
        ) {
            AsyncImage(
                model = photoFile,
                contentDescription = "Ảnh lớn đơn $orderCode",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .align(Alignment.Center)
            )

            Surface(
                color = Color.Black.copy(alpha = 0.6f),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Đóng ảnh",
                        tint = Color.White
                    )
                }
            }

            Text(
                text = "Mã đơn: $orderCode",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 16.dp)
            )
        }
    }
}
