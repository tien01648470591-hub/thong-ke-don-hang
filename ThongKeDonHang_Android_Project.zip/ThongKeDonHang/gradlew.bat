@rem Gradle Wrapper startup script for Windows
@echo off
gradle %*
