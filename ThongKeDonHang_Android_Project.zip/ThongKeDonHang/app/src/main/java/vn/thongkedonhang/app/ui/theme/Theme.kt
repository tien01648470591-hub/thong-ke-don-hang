package vn.thongkedonhang.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightWhiteYellowColorScheme = lightColorScheme(
    primary = PrimaryYellow,
    onPrimary = OnPrimaryYellow,
    primaryContainer = PrimaryYellowContainer,
    onPrimaryContainer = TextPrimaryDark,
    secondary = PrimaryYellowDark,
    onSecondary = Color.White,
    secondaryContainer = PrimaryYellowContainer,
    onSecondaryContainer = TextPrimaryDark,
    background = WhiteBackground,
    onBackground = TextPrimaryDark,
    surface = WhiteBackground,
    onSurface = TextPrimaryDark,
    surfaceVariant = SoftCreamSurface,
    onSurfaceVariant = TextSecondaryGray,
    error = StatusCancelledRed,
    onError = Color.White
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp)
)

@Composable
fun ThongKeDonHangTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightWhiteYellowColorScheme,
        shapes = AppShapes,
        content = content
    )
}
