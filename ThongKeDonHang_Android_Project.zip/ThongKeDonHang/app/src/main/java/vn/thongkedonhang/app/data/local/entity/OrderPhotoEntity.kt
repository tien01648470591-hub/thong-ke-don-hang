package vn.thongkedonhang.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Bảng lưu thông tin Ảnh đính kèm của từng đơn hàng (Phần 5).
 * Tối đa 3 ảnh / đơn hàng, giữ đúng quan hệ với order_id.
 */
@Entity(
    tableName = "order_photos",
    foreignKeys = [
        ForeignKey(
            entity = OrderEntity::class,
            parentColumns = ["id"],
            childColumns = ["order_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["order_id"])
    ]
)
data class OrderPhotoEntity(
    @PrimaryKey
    @ColumnInfo(name = "photo_id")
    val photoId: String,

    @ColumnInfo(name = "order_id")
    val orderId: String,

    @ColumnInfo(name = "relative_path")
    val relativePath: String,

    @ColumnInfo(name = "position")
    val position: Int,

    @ColumnInfo(name = "created_at_millis")
    val createdAtMillis: Long
)
