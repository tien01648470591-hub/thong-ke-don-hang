package vn.thongkedonhang.app.ui.theme

import androidx.compose.ui.graphics.Color

// Màu sắc chủ đạo theo Phần 2:
// - Trắng là màu nền chủ đạo
// - Vàng là màu nhấn chính
// - Xanh lá: Giao thành công
// - Vàng: Chờ chuyển khoản
// - Đỏ: Hủy đơn

val WhiteBackground = Color(0xFFFFFFFF)
val SoftCreamSurface = Color(0xFFFFFDF7)
val CardGrayBorder = Color(0xFFE5E7EB)

val PrimaryYellow = Color(0xFFF59E0B)
val PrimaryYellowDark = Color(0xFFD97706)
val PrimaryYellowContainer = Color(0xFFFEF3C7)
val OnPrimaryYellow = Color(0xFF1F2937)

val StatusSuccessGreen = Color(0xFF16A34A)
val StatusSuccessBg = Color(0xFFDCFCE7)

val StatusWaitingYellow = Color(0xFFD97706)
val StatusWaitingBg = Color(0xFFFEF9C3)

val StatusCancelledRed = Color(0xFFDC2626)
val StatusCancelledBg = Color(0xFFFEE2E2)

val TextPrimaryDark = Color(0xFF111827)
val TextSecondaryGray = Color(0xFF4B5563)
