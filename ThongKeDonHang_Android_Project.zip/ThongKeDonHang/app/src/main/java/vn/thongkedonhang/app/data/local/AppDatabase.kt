package vn.thongkedonhang.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import vn.thongkedonhang.app.data.local.dao.OrderDao
import vn.thongkedonhang.app.data.local.entity.OrderEntity
import vn.thongkedonhang.app.data.local.entity.OrderGroupEntity
import vn.thongkedonhang.app.data.local.entity.OrderPhotoEntity

@Database(
    entities = [
        OrderEntity::class,
        OrderPhotoEntity::class,
        OrderGroupEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun orderDao(): OrderDao

    companion object {
        private const val DATABASE_NAME = "thong_ke_don_hang.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_NAME
                )
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
