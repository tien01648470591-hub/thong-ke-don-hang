package vn.thongkedonhang.app

import android.app.Application
import vn.thongkedonhang.app.data.backup.BackupRestoreManager
import vn.thongkedonhang.app.data.local.AppDatabase
import vn.thongkedonhang.app.data.repository.OrderRepository
import vn.thongkedonhang.app.data.storage.PhotoStorageManager

class ThongKeDonHangApp : Application() {

    val database: AppDatabase by lazy {
        AppDatabase.getInstance(this)
    }

    val photoStorageManager: PhotoStorageManager by lazy {
        PhotoStorageManager(this)
    }

    val backupRestoreManager: BackupRestoreManager by lazy {
        BackupRestoreManager(
            context = this,
            orderDao = database.orderDao(),
            photoStorageManager = photoStorageManager
        )
    }

    val repository: OrderRepository by lazy {
        OrderRepository(
            orderDao = database.orderDao(),
            photoStorageManager = photoStorageManager,
            backupRestoreManager = backupRestoreManager
        )
    }
}
