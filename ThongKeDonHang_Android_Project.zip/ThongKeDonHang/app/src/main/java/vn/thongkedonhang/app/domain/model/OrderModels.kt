package vn.thongkedonhang.app.domain.model

/**
 * Hằng số quy tắc nghiệp vụ cốt lõi:
 * - Tối đa 100 đơn hàng trong một ngày thống kê riêng biệt (Phần 10).
 * - Tối đa 3 ảnh đính kèm cho mỗi đơn hàng (Phần 5).
 * - Khoảng thời gian báo cáo tối đa 1 tháng (31 ngày) (Phần 10).
 */
object OrderConstants {
    const val MAX_ORDERS_PER_DAY = 100
    const val MAX_PHOTOS_PER_ORDER = 3
    const val MAX_REPORT_DAYS = 31L
}

data class OrderPhoto(
    val photoId: String,
    val orderId: String,
    val relativePath: String,
    val position: Int,
    val createdAtMillis: Long
)

data class OrderItem(
    val id: String,
    val orderCode: String,
    val codeSuffix4: String,
    val amountVnd: Long,
    val status: OrderStatus,
    val statDate: String, // Định dạng chuẩn ISO yyyy-MM-dd
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val groupId: String?,
    val groupName: String?,
    val groupCode: String?,
    val note: String,
    val photos: List<OrderPhoto>
)

/**
 * Thống kê tổng hợp theo đúng Quy tắc Phần 7 (BẮT BUỘC TUÂN THỦ):
 * - Tổng giá trị tất cả đơn (totalAllAmountVnd) BAO GỒM cả đơn Giao thành công, Chờ chuyển khoản và Hủy đơn.
 * - Đơn hủy KHÔNG ĐƯỢC tự động trừ khỏi tổng giá trị tất cả đơn.
 * - Không gọi tổng giá trị tất cả đơn là tiền thực nhận.
 */
data class OrderSummaryStats(
    val dateOrRangeLabel: String,
    val totalOrders: Int,
    val totalAllAmountVnd: Long,
    val deliveredCount: Int,
    val deliveredAmountVnd: Long,
    val waitingCount: Int,
    val waitingAmountVnd: Long,
    val cancelledCount: Int,
    val cancelledAmountVnd: Long,
    val dailyLimit: Int = OrderConstants.MAX_ORDERS_PER_DAY,
    val remainingDailyQuota: Int = (OrderConstants.MAX_ORDERS_PER_DAY - totalOrders).coerceAtLeast(0)
)

/**
 * Mô hình Nhóm đơn gộp (Phần 8):
 * Một người hoặc một nhóm xử lý có nhiều mã đơn.
 * Mỗi đơn chỉ thuộc tối đa một nhóm tại cùng một thời điểm.
 */
data class OrderGroupSummary(
    val groupId: String,
    val groupCode: String,
    val groupName: String,
    val note: String,
    val createdDate: String,
    val createdAtMillis: Long,
    val orders: List<OrderItem>,
    val stats: OrderSummaryStats
)

/**
 * Kết quả trả về từ tầng xử lý dữ liệu để kiểm soát chặt chẽ các ràng buộc.
 */
sealed class DomainResult<out T> {
    data class Success<T>(val data: T) : DomainResult<T>()
    data class DuplicateOrderSameDay(
        val existingOrder: OrderItem,
        val message: String
    ) : DomainResult<Nothing>()
    data class DailyLimitExceeded(
        val statDate: String,
        val message: String = "Ngày này đã đạt giới hạn 100 đơn"
    ) : DomainResult<Nothing>()
    data class PhotoLimitExceeded(
        val message: String = "Mỗi đơn hàng chỉ được đính kèm tối đa 3 ảnh"
    ) : DomainResult<Nothing>()
    data class ValidationError(val message: String) : DomainResult<Nothing>()
}
