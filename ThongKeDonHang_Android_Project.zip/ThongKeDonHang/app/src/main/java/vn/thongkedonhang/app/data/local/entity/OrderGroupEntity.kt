package vn.thongkedonhang.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Bảng lưu thông tin Nhóm đơn gộp (Phần 8).
 */
@Entity(
    tableName = "order_groups",
    indices = [
        Index(value = ["group_code"], unique = true),
        Index(value = ["created_date"])
    ]
)
data class OrderGroupEntity(
    @PrimaryKey
    @ColumnInfo(name = "group_id")
    val groupId: String,

    @ColumnInfo(name = "group_code")
    val groupCode: String,

    @ColumnInfo(name = "group_name")
    val groupName: String,

    @ColumnInfo(name = "note")
    val note: String = "",

    @ColumnInfo(name = "created_date")
    val createdDate: String,

    @ColumnInfo(name = "created_at_millis")
    val createdAtMillis: Long
)
