package vn.thongkedonhang.app.data.local.entity

import androidx.room.Embedded
import androidx.room.Relation
import vn.thongkedonhang.app.domain.model.OrderItem
import vn.thongkedonhang.app.domain.model.OrderPhoto
import vn.thongkedonhang.app.domain.model.OrderStatus

/**
 * Quan hệ Room kết hợp Đơn hàng + Danh sách Ảnh đính kèm + Nhóm đơn gộp.
 */
data class OrderWithDetailsRelation(
    @Embedded
    val order: OrderEntity,

    @Relation(
        parentColumn = "id",
        entityColumn = "order_id"
    )
    val photos: List<OrderPhotoEntity>,

    @Relation(
        parentColumn = "group_id",
        entityColumn = "group_id"
    )
    val group: OrderGroupEntity?
) {
    fun toDomainModel(): OrderItem {
        return OrderItem(
            id = order.id,
            orderCode = order.orderCode,
            codeSuffix4 = order.codeSuffix4,
            amountVnd = order.amountVnd,
            status = OrderStatus.fromName(order.status),
            statDate = order.statDate,
            createdAtMillis = order.createdAtMillis,
            updatedAtMillis = order.updatedAtMillis,
            groupId = order.groupId,
            groupName = group?.groupName,
            groupCode = group?.groupCode,
            note = order.note,
            photos = photos.sortedBy { it.position }.map {
                OrderPhoto(
                    photoId = it.photoId,
                    orderId = it.orderId,
                    relativePath = it.relativePath,
                    position = it.position,
                    createdAtMillis = it.createdAtMillis
                )
            }
        )
    }
}
