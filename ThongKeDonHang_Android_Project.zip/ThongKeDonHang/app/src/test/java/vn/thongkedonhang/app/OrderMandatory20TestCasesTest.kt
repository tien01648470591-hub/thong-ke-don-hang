package vn.thongkedonhang.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import vn.thongkedonhang.app.domain.model.OrderConstants
import vn.thongkedonhang.app.domain.model.OrderItem
import vn.thongkedonhang.app.domain.model.OrderPhoto
import vn.thongkedonhang.app.domain.model.OrderStatus
import vn.thongkedonhang.app.domain.util.OrderCalculator

/**
 * Bộ Kiểm thử tự động JUnit4 cho 20 tình huống bắt buộc (Phần 14).
 */
class OrderMandatory20TestCasesTest {

    private fun createSampleOrder(
        id: String,
        code: String,
        amountVnd: Long,
        status: OrderStatus = OrderStatus.DELIVERED_SUCCESS,
        statDate: String = "2026-10-22",
        groupId: String? = null,
        groupName: String? = null,
        photoCount: Int = 0
    ): OrderItem {
        val photos = (0 until photoCount).map { idx ->
            OrderPhoto(
                photoId = "p_${id}_$idx",
                orderId = id,
                relativePath = "$id/p_$idx.jpg",
                position = idx,
                createdAtMillis = 1700000000000L + idx
            )
        }
        return OrderItem(
            id = id,
            orderCode = code,
            codeSuffix4 = OrderCalculator.extractSuffix4(code),
            amountVnd = amountVnd,
            status = status,
            statDate = statDate,
            createdAtMillis = 1700000000000L,
            updatedAtMillis = 1700000000000L,
            groupId = groupId,
            groupName = groupName,
            groupCode = if (groupId != null) "GRP-001" else null,
            note = "",
            photos = photos
        )
    }

    @Test
    fun test01_02_03_createOrderByQr_Barcode_AndManual() {
        val qrOrder = createSampleOrder("1", "QR-VN-2026-8899", 120_000L)
        val barcodeOrder = createSampleOrder("2", "8938505974192", 85_000L)
        val manualOrder = createSampleOrder("3", "SPXVN0192834412", 200_000L)

        assertEquals("8899", qrOrder.codeSuffix4)
        assertEquals("4192", barcodeOrder.codeSuffix4)
        assertEquals("4412", manualOrder.codeSuffix4)
        val stats = OrderCalculator.calculateStats(listOf(qrOrder, barcodeOrder, manualOrder))
        assertEquals(3, stats.totalOrders)
        assertEquals(405_000L, stats.totalAllAmountVnd)
    }

    @Test
    fun test04_zeroAmountOrderIsValidAndCounted() {
        val zeroOrder = createSampleOrder("1", "ZERO-0001", OrderCalculator.parseAmountVnd(""))
        assertEquals(0L, zeroOrder.amountVnd)
        assertEquals("0 ₫", OrderCalculator.formatVnd(zeroOrder.amountVnd))

        val stats = OrderCalculator.calculateStats(listOf(zeroOrder))
        assertEquals(1, stats.totalOrders)
        assertEquals(0L, stats.totalAllAmountVnd)
        assertEquals(1, stats.deliveredCount)
    }

    @Test
    fun test05_largeAmountFormatting() {
        val amount = OrderCalculator.parseAmountVnd("12500000")
        assertEquals(12_500_000L, amount)
        val formatted = OrderCalculator.formatVnd(amount)
        assertTrue(formatted.contains("12.500.000") && formatted.endsWith("₫"))
    }

    @Test
    fun test06_max3PhotosLimitEnforcement() {
        val orderWith3 = createSampleOrder("1", "IMG-1003", 100_000L, photoCount = 3)
        assertEquals(OrderConstants.MAX_PHOTOS_PER_ORDER, orderWith3.photos.size)
        val canAdd4th = orderWith3.photos.size < OrderConstants.MAX_PHOTOS_PER_ORDER
        assertFalse("Không được phép thêm ảnh thứ 4", canAdd4th)
    }

    @Test
    fun test07_08_dailyLimit100OrdersAndReject101st() {
        val hundredOrders = (1..100).map { i ->
            createSampleOrder(
                id = "id_$i",
                code = "ORD-${i.toString().padStart(4, '0')}",
                amountVnd = 10_000L
            )
        }
        val stats = OrderCalculator.calculateStats(hundredOrders)
        assertEquals(100, stats.totalOrders)
        assertEquals(0, stats.remainingDailyQuota)
        assertEquals(1_000_000L, stats.totalAllAmountVnd)
    }

    @Test
    fun test09_switchDatePreservesOldDateData() {
        val day1Orders = listOf(
            createSampleOrder("1", "D1-1111", 100_000L, statDate = "2026-10-21"),
            createSampleOrder("2", "D1-2222", 150_000L, statDate = "2026-10-21")
        )
        val day2Orders = listOf(
            createSampleOrder("3", "D2-3333", 200_000L, statDate = "2026-10-22")
        )
        val all = day1Orders + day2Orders
        val filteredDay1 = all.filter { it.statDate == "2026-10-21" }
        assertEquals(2, filteredDay1.size)
        assertEquals(250_000L, OrderCalculator.calculateStats(filteredDay1).totalAllAmountVnd)
    }

    @Test
    fun test10_11_searchByLast4DigitsSingleAndMultipleMatches() {
        val orders = listOf(
            createSampleOrder("1", "SPXVN00119876", 100_000L, status = OrderStatus.DELIVERED_SUCCESS),
            createSampleOrder("2", "GHN99889876", 150_000L, status = OrderStatus.WAITING_TRANSFER),
            createSampleOrder("3", "JNT77779876", 200_000L, status = OrderStatus.CANCELLED),
            createSampleOrder("4", "VIETTEL1234", 90_000L, status = OrderStatus.DELIVERED_SUCCESS)
        )
        val matches9876 = orders.filter { OrderCalculator.matchesSuffixQuery(it.orderCode, "9876") }
        assertEquals("Phải trả về cả 3 đơn trùng 4 số cuối 9876 (gồm cả đơn hủy)", 3, matches9876.size)

        val matches1234 = orders.filter { OrderCalculator.matchesSuffixQuery(it.orderCode, "1234") }
        assertEquals(1, matches1234.size)
        assertEquals("VIETTEL1234", matches1234.first().orderCode)
    }

    @Test
    fun test12_13_orderGroupingAndMovingBetweenGroups() {
        val o1 = createSampleOrder("1", "G-0001", 100_000L, OrderStatus.DELIVERED_SUCCESS, groupId = "grpA")
        val o2 = createSampleOrder("2", "G-0002", 150_000L, OrderStatus.WAITING_TRANSFER, groupId = "grpA")
        val o3 = createSampleOrder("3", "G-0003", 100_000L, OrderStatus.CANCELLED, groupId = "grpA")

        val groupAStats = OrderCalculator.calculateStats(listOf(o1, o2, o3))
        assertEquals(3, groupAStats.totalOrders)
        assertEquals("Tổng giá trị nhóm phải là 350.000đ kể cả khi mã thứ 3 bị hủy", 350_000L, groupAStats.totalAllAmountVnd)

        // Chuyển o2 sang grpB
        val movedO2 = o2.copy(groupId = "grpB")
        val newGroupAStats = OrderCalculator.calculateStats(listOf(o1, o3))
        val newGroupBStats = OrderCalculator.calculateStats(listOf(movedO2))
        assertEquals(200_000L, newGroupAStats.totalAllAmountVnd)
        assertEquals(150_000L, newGroupBStats.totalAllAmountVnd)
    }

    @Test
    fun test14_15_changeStatusAndCancelOrderNeverReducesTotalAllAmount() {
        // Ví dụ bắt buộc trong Phần 7:
        // Đơn A: 100.000 đồng, giao thành công
        // Đơn B: 150.000 đồng, chờ chuyển khoản
        // Đơn C: 100.000 đồng, hủy đơn
        val orderA = createSampleOrder("A", "ORD-A001", 100_000L, OrderStatus.DELIVERED_SUCCESS)
        val orderB = createSampleOrder("B", "ORD-B002", 150_000L, OrderStatus.WAITING_TRANSFER)
        val orderC = createSampleOrder("C", "ORD-C003", 100_000L, OrderStatus.CANCELLED)

        val stats = OrderCalculator.calculateStats(listOf(orderA, orderB, orderC))
        assertEquals(3, stats.totalOrders)
        assertEquals(350_000L, stats.totalAllAmountVnd)
        assertEquals(100_000L, stats.deliveredAmountVnd)
        assertEquals(150_000L, stats.waitingAmountVnd)
        assertEquals(100_000L, stats.cancelledAmountVnd)

        // Đổi Đơn A từ Giao thành công sang Hủy đơn -> Tổng giá trị tất cả đơn KHÔNG thay đổi (vẫn 350.000đ)
        val cancelledOrderA = orderA.copy(status = OrderStatus.CANCELLED)
        assertEquals("Giá tiền đơn hủy phải giữ nguyên", 100_000L, cancelledOrderA.amountVnd)
        val statsAfterCancel = OrderCalculator.calculateStats(listOf(cancelledOrderA, orderB, orderC))
        assertEquals(350_000L, statsAfterCancel.totalAllAmountVnd)
        assertEquals(0L, statsAfterCancel.deliveredAmountVnd)
        assertEquals(200_000L, statsAfterCancel.cancelledAmountVnd)
    }

    @Test
    fun test16_deleteOrderRecalculatesStatsCorrectly() {
        val orderA = createSampleOrder("A", "ORD-A001", 100_000L, OrderStatus.DELIVERED_SUCCESS)
        val orderB = createSampleOrder("B", "ORD-B002", 150_000L, OrderStatus.WAITING_TRANSFER)
        val afterDelete = listOf(orderA)
        val stats = OrderCalculator.calculateStats(afterDelete)
        assertEquals(1, stats.totalOrders)
        assertEquals(100_000L, stats.totalAllAmountVnd)
    }

    @Test
    fun test19_20_validateOneMonthReportLimitAndTotalConsistency() {
        val validRange = OrderCalculator.validateDateRangeMaxOneMonth("2026-10-01", "2026-10-31")
        assertTrue(validRange.isSuccess)
        assertEquals(31L, validRange.getOrNull())

        val invalidRange = OrderCalculator.validateDateRangeMaxOneMonth("2026-10-01", "2026-11-05")
        assertTrue("Khoảng 36 ngày phải bị từ chối vì vượt quá 31 ngày", invalidRange.isFailure)
    }
}
