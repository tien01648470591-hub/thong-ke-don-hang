package vn.thongkedonhang.app.data.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Quản lý lưu trữ ảnh nội bộ an toàn theo yêu cầu Phần 1 & Phần 5:
 * - Lưu ảnh của từng đơn vào thư mục riêng biệt: filesDir/order_photos/{orderId}/{photoId}.jpg
 * - Không bao giờ nhầm lẫn ảnh giữa các đơn khác nhau.
 * - Khi xóa 1 ảnh hoặc xóa 1 đơn, chỉ xóa đúng tệp ảnh thuộc đơn đó, không ảnh hưởng đơn khác.
 * - Ảnh tồn tại bền vững sau khi đóng ứng dụng hoặc khởi động lại điện thoại.
 */
class PhotoStorageManager(private val context: Context) {

    val rootPhotosDir: File
        get() = File(context.filesDir, "order_photos").apply {
            if (!exists()) mkdirs()
        }

    private val cameraTempDir: File
        get() = File(context.cacheDir, "camera_capture").apply {
            if (!exists()) mkdirs()
        }

    /**
     * Tạo tệp tạm và Uri qua FileProvider để chụp ảnh trực tiếp bằng Camera.
     */
    fun createTempCameraCaptureUri(): Pair<File, Uri> {
        val tempFile = File(cameraTempDir, "capture_${System.currentTimeMillis()}_${UUID.randomUUID()}.jpg")
        val authority = "${context.packageName}.fileprovider"
        val uri = FileProvider.getUriForFile(context, authority, tempFile)
        return tempFile to uri
    }

    /**
     * Sao chép ảnh từ Uri (Photo Picker hoặc Camera) vào bộ nhớ nội bộ của đơn hàng.
     * Trả về đường dẫn tương đối (relativePath) dạng "{orderId}/{photoId}.jpg".
     */
    suspend fun copyUriToOrderInternalStorage(
        orderId: String,
        photoId: String,
        sourceUri: Uri
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val safeOrderId = sanitizeSegment(orderId)
            val safePhotoId = sanitizeSegment(photoId)
            val orderDir = File(rootPhotosDir, safeOrderId).apply {
                if (!exists()) mkdirs()
            }
            val destFile = File(orderDir, "$safePhotoId.jpg")

            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                // Giải mã và nén nhẹ JPEG chất lượng 88% nếu là bitmap hợp lệ để tiết kiệm bộ nhớ,
                // hoặc chép trực tiếp luồng byte nếu không giải mã được bitmap.
                val bytes = input.readBytes()
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                FileOutputStream(destFile).use { out ->
                    if (bitmap != null) {
                        val scaled = scaleDownIfNeeded(bitmap, 1600)
                        scaled.compress(Bitmap.CompressFormat.JPEG, 88, out)
                        if (scaled != bitmap) scaled.recycle()
                        bitmap.recycle()
                    } else {
                        out.write(bytes)
                    }
                    out.flush()
                }
            } ?: return@withContext Result.failure(IllegalArgumentException("Không thể đọc tệp ảnh đã chọn."))

            val relativePath = "$safeOrderId/$safePhotoId.jpg"
            Result.success(relativePath)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Sao chép từ tệp ảnh nguồn vào bộ nhớ nội bộ của đơn hàng (dùng cho Camera hoặc Kiểm thử).
     */
    suspend fun copyFileToOrderInternalStorage(
        orderId: String,
        photoId: String,
        sourceFile: File
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (!sourceFile.exists()) {
                return@withContext Result.failure(IllegalArgumentException("Tệp ảnh nguồn không tồn tại."))
            }
            val safeOrderId = sanitizeSegment(orderId)
            val safePhotoId = sanitizeSegment(photoId)
            val orderDir = File(rootPhotosDir, safeOrderId).apply {
                if (!exists()) mkdirs()
            }
            val destFile = File(orderDir, "$safePhotoId.jpg")
            sourceFile.copyTo(destFile, overwrite = true)
            Result.success("$safeOrderId/$safePhotoId.jpg")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Trả về đối tượng File tuyệt đối từ đường dẫn tương đối đã lưu trong DB.
     */
    fun resolvePhotoFile(relativePath: String): File {
        return File(rootPhotosDir, relativePath)
    }

    /**
     * Xóa một tệp ảnh riêng lẻ của đơn hàng mà không ảnh hưởng đến ảnh khác.
     */
    suspend fun deleteSinglePhotoFile(relativePath: String) = withContext(Dispatchers.IO) {
        try {
            val file = resolvePhotoFile(relativePath)
            if (file.exists() && file.canonicalPath.startsWith(rootPhotosDir.canonicalPath)) {
                file.delete()
            }
        } catch (_: Exception) {
        }
    }

    /**
     * Xóa toàn bộ thư mục ảnh của riêng một đơn hàng khi đơn hàng đó bị xóa.
     * Đảm bảo tuyệt đối không xóa nhầm ảnh của đơn hàng khác.
     */
    suspend fun deleteAllPhotosForOrder(orderId: String) = withContext(Dispatchers.IO) {
        try {
            val safeOrderId = sanitizeSegment(orderId)
            if (safeOrderId.isBlank()) return@withContext
            val orderDir = File(rootPhotosDir, safeOrderId)
            if (orderDir.exists() && orderDir.canonicalPath.startsWith(rootPhotosDir.canonicalPath)) {
                orderDir.deleteRecursively()
            }
        } catch (_: Exception) {
        }
    }

    private fun sanitizeSegment(raw: String): String {
        return raw.replace(Regex("[^a-zA-Z0-9_-]"), "_")
    }

    private fun scaleDownIfNeeded(source: Bitmap, maxDimension: Int): Bitmap {
        val width = source.width
        val height = source.height
        if (width <= maxDimension && height <= maxDimension) return source
        val ratio = width.toFloat() / height.toFloat()
        val (newW, newH) = if (ratio > 1f) {
            maxDimension to (maxDimension / ratio).toInt().coerceAtLeast(1)
        } else {
            (maxDimension * ratio).toInt().coerceAtLeast(1) to maxDimension
        }
        return Bitmap.createScaledBitmap(source, newW, newH, true)
    }
}
